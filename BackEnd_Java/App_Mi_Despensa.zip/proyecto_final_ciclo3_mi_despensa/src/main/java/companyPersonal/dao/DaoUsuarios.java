package companyPersonal.dao;

import companyPersonal.modelos.Usuarios;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
//import javax.swing.JOptionPane;


public class DaoUsuarios extends Conexion implements InterfazDaoUsuarios{

    @Override
    public Usuarios verUsuario(Usuarios usuarioAConsultar/*, VistaApp vistaApp*/) {
    //Consultamos en base de datos por cedula, si el usuario ya existe o no.  
        String sql = "SELECT * FROM " + Constantes.TBL_USUARIOS + 
                     " WHERE " + Constantes.TBL_USUARIOS_CEDULA + " = " + usuarioAConsultar.getCedula() + " OR " + Constantes.TBL_USUARIOS_CORREO + " = '" + usuarioAConsultar.getCorreoE() + "'";
        
        Usuarios usuarioConsultado = new Usuarios();        
        
        try {
            
            Connection connection = getConexion();
            
            if(connection == null){
            	System.err.println(" ===> Error 2: Error al conectar a la base de datos ");
            	usuarioConsultado.setCedula(999999999);
            	System.out.println("Prueba de Escritorio 2 => El usuario actual es => " + usuarioConsultado); //Prueba de Escritorio
            	System.out.println("Prueba de Escritorio 2 => La conexion es => " + connection); //Prueba de Escritorio 
            }
            else {
            
	            PreparedStatement ps = connection.prepareStatement(sql);
	            ResultSet resultSet = ps.executeQuery();
	            
	            while (resultSet.next()) {                
	                
	                usuarioConsultado.setId(resultSet.getInt(Constantes.TBL_USUARIOS_ID));
	                usuarioConsultado.setCedula(resultSet.getInt(Constantes.TBL_USUARIOS_CEDULA));
	                usuarioConsultado.setNombre(resultSet.getString(Constantes.TBL_USUARIOS_NOMBRE));
	                usuarioConsultado.setCorreoE(resultSet.getString(Constantes.TBL_USUARIOS_CORREO));
	                usuarioConsultado.setValorAcomuladoObsequios(resultSet.getInt(Constantes.TBL_USUARIOS_VALOR_OBQ_ACOMU));
	                usuarioConsultado.setEstado(resultSet.getInt(Constantes.TBL_USUARIOS_ID_ESTADO));
	                
	            }
            }
            
        } 
        
        catch (Exception e) {
            
            //JOptionPane.showMessageDialog(null, "Error al leer los datos de la BD " + e);
            System.err.println(" ===> Error 3 => Error al leer los datos de la BD: " + e.getMessage());
            usuarioConsultado.setCedula(999999999);
            //return usuarioConsultado; 
        }
        finally {
            try {
                getConexion().close();
            } 
            catch (Exception e) {
            	//JOptionPane.showMessageDialog(null, "Error al cerrar la conexión" + e.getMessage()); 
            	System.err.println(" ===>Error 4 => Error al cerrar la conexión: " + e.getMessage());
            }
        }
        //System.out.println("Prueba de Escritorio 3 => El usuario actual es => " + usuarioConsultado);
        return usuarioConsultado;  
    }     
    
    
    
    @Override
    public ArrayList<Usuarios> verUsuarios(/*VistaApp vistaApp*/) {
        //Constultamos en base de datos todos los usuarios existentes.
        //Este metodo no se usa, se creo para pruebas.
        ArrayList<Usuarios> arrayListUsuarios = new ArrayList<>();
        
        String sql = "SELECT * FROM " + Constantes.TBL_USUARIOS + " ORDER BY " + Constantes.TBL_USUARIOS_ID + " DESC";
        
        try {
            
            Connection connection = getConexion();
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet resultSet = ps.executeQuery();
            
            while (resultSet.next()) {                
                Usuarios usuario = new Usuarios();
                usuario.setId(resultSet.getInt(Constantes.TBL_USUARIOS_ID));
                usuario.setCedula(resultSet.getInt(Constantes.TBL_USUARIOS_CEDULA));
                usuario.setNombre(resultSet.getString(Constantes.TBL_USUARIOS_NOMBRE));
                usuario.setCorreoE(resultSet.getString(Constantes.TBL_USUARIOS_CORREO));
                usuario.setValorAcomuladoObsequios(resultSet.getInt(Constantes.TBL_USUARIOS_VALOR_OBQ_ACOMU));
                usuario.setEstado(resultSet.getInt(Constantes.TBL_USUARIOS_ID_ESTADO));
                
                arrayListUsuarios.add(usuario);
            }
            
        } 
        catch (SQLException e) {
            
            //JOptionPane.showMessageDialog(null, "Error al leer los datos de la BD " + e);
            System.err.println(" ===> Error al leer los datos de la BD: " + e.getMessage());
            return arrayListUsuarios; //quedaria vacio
        }
        finally {
            try {
                getConexion().close();
            } 
            catch (SQLException e) {
            	//JOptionPane.showMessageDialog(null, "Error al cerrar la conexión" + e.getMessage()); 
            	System.err.println(" ===> Error al cerrar la conexión: " + e.getMessage());
            }
        }
        return arrayListUsuarios;  
    } 
    
    @Override
    public boolean crearUsuario(Usuarios usuario/*, VistaApp vistaApp*/) {
        //En base de datos creamos el usuario con todos los datos ingresados por el usuario.
        String sql = "INSERT INTO " + Constantes.TBL_USUARIOS + "(" + Constantes.TBL_USUARIOS_CEDULA + ", " 
                                                                    + Constantes.TBL_USUARIOS_NOMBRE + ", "
                                                                    + Constantes.TBL_USUARIOS_CORREO + ", "
                                                                    + Constantes.TBL_USUARIOS_VALOR_OBQ_ACOMU + ", "
                                                                    + Constantes.TBL_USUARIOS_ID_ESTADO + ") VALUES (?,?,?,?,?)";
        try {
            Connection connection = getConexion();
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setInt(1, usuario.getCedula());
            ps.setString(2, usuario.getNombre());
            ps.setString(3, usuario.getCorreoE());
            ps.setInt(4, usuario.getValorAcomuladoObsequios());
            ps.setInt(5, usuario.getEstado());
            ps.executeUpdate();
            
            //JOptionPane.showMessageDialog(null, " ==> El usuario con el número de cedula '" + usuario.getCedula() + 
            //                    "' no se encontraba registrado en la base de datos, por tanto, el usuario " +
            //                    "con la información ingresada fue creado con exito! ");
            
            System.out.println(" ==> El usuario con el número de cedula '" + usuario.getCedula() + 
                                        "' no se encontraba registrado en la base de datos, por tanto, el usuario " +
                                        "con la información ingresada fue creado con exito! ");
        } 
        catch (SQLException e) {
            System.err.println("Error al crear el usuario " + e.getMessage());
            return false;
        }
        finally {
            try {
                getConexion().close();
            } 
            catch (SQLException e) {
            	System.out.println( "Error al cerrar la conexión" + e.getMessage());                
            }
        }
        return true;
    }
    
    @Override
    public boolean actualizarInfoUsuarioObsequios(Usuarios usuario, Integer totalObsequios/*, VistaApp vistaApp*/){
    // En base de datos, Actualizamos el usuario correspondiente en su campo valor_obsequios_acomulados    
        String sql = "UPDATE " + Constantes.TBL_USUARIOS + " SET " + Constantes.TBL_USUARIOS_VALOR_OBQ_ACOMU + " = " 
                + (usuario.getValorAcomuladoObsequios() + totalObsequios) + " WHERE " 
                + Constantes.TBL_USUARIOS_ID + " = " + usuario.getId();
        try {
            Connection connection = getConexion();
            PreparedStatement ps = connection.prepareStatement(sql);
            //ps.setInt(1, pedido.getId());
            //ps.setInt(2, productoAdd.getId());
            ps.executeUpdate();
            
            System.out.println("==> El valor de Obsequios ha sido actualizado y puede verlo en los datos de su perfil!");
            
        } 
        catch (SQLException e) {
        	System.err.println( "Error actualizando el valor de obsequios en la BD " + e.getMessage());
            return false;
        }
        finally {
            try {
                getConexion().close();
            } 
            catch (SQLException e) {
            	System.err.println("Error al cerrar la conexión" + e.getMessage());                
            }
        }
        return true; 
    }
}
