package companyPersonal.dao;

import companyPersonal.modelos.CarritosPedidos;
import companyPersonal.modelos.Pedidos;
import companyPersonal.modelos.Productos;
//import companyPersonal.modelos.Usuarios;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class DaoProductos extends Conexion implements InterfazDaoProductos{
    // En la base de datos consultamos todos los productos asociados al tipo de productos (comestibles, liquidos o de aseo)
    @Override
    public ArrayList<Productos> inventarioProductosTipo(int tipoProductos) {
              
        ArrayList<Productos> invProductosTipo = new ArrayList<>(); // Se crea arraylist donde agregamos objetos de tipo Productos con sus atributos correspondientes traidos de la Base de datos
        
        String sql = "SELECT * FROM " + Constantes.TBL_PRODUCTOS + " WHERE " + Constantes.TBL_PRODUCTOS_ID_CATEG + " = " + tipoProductos + " ORDER BY " + Constantes.TBL_PRODUCTOS_ID + " ASC";
        
        try {
            
            Connection connection = getConexion();
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet resultSet = ps.executeQuery();
            
            while (resultSet.next()) {                
                Productos producto = new Productos();
                producto.setId(resultSet.getInt(Constantes.TBL_PRODUCTOS_ID));
                producto.setCodBarras(resultSet.getString(Constantes.TBL_PRODUCTOS_COD_BARRAS));
                producto.setNombreProducto(resultSet.getString(Constantes.TBL_PRODUCTOS_NOMBRE_PRODUCTO));
                producto.setMarca(resultSet.getString(Constantes.TBL_PRODUCTOS_MARCA));
                producto.setfVencimiento(resultSet.getDate(Constantes.TBL_PRODUCTOS_FECHA_VENC));
                producto.setPrecioSinIva(resultSet.getInt(Constantes.TBL_PRODUCTOS_PRECIO_SIN_IVA));
                producto.setIva(resultSet.getFloat(Constantes.TBL_PRODUCTOS_IVA));
                producto.setPrecioConIva(resultSet.getInt(Constantes.TBL_PRODUCTOS_PRECIO_CON_IVA));
                producto.setDescuento(resultSet.getFloat(Constantes.TBL_PRODUCTOS_DESCUENTO));
                producto.setCategoria(resultSet.getInt(Constantes.TBL_PRODUCTOS_ID_CATEG));
                producto.setIdEstado(resultSet.getInt(Constantes.TBL_PRODUCTOS_ID_ESTADO));
                producto.setValorObsequio((int)(((resultSet.getInt(Constantes.TBL_PRODUCTOS_PRECIO_CON_IVA) //Se realiza operación
                - (resultSet.getInt(Constantes.TBL_PRODUCTOS_PRECIO_CON_IVA)                   // para calcualar el valor de obsequio
                *resultSet.getFloat(Constantes.TBL_PRODUCTOS_DESCUENTO)))/10000))*1000);  // y se asigna al atributo "valorObsequio" 
                                                                                            // del objeto de clase Productos.
                invProductosTipo.add(producto);
            }
            
        } 
        catch (SQLException e) {
            
            System.out.println("Error al leer los datos de la BD " + e);
            return invProductosTipo; //quedaria vacio
        }
        finally {
            try {
                getConexion().close();
            } 
            catch (SQLException e) {
            System.err.println("Error al cerrar la conexión" + e.getMessage());                
            }
        }
        return invProductosTipo;
    }

    @Override
    public ArrayList<Productos> inventarioProductosPromocion() {
        // En la base de datos consultamos todos los productos de cualquier tipo(comestibles, liquidos o de aseo) que tenga promoción     
        ArrayList<Productos> invProductosPromo = new ArrayList<>(); // Se crea arraylist donde agregamos objetos de tipo Productos con sus atributos correspondientes traidos de la Base de datos
        
        String sql = "SELECT * FROM " + Constantes.TBL_PRODUCTOS + " WHERE " + Constantes.TBL_PRODUCTOS_DESCUENTO + " != 0 ORDER BY " + Constantes.TBL_PRODUCTOS_ID + " ASC";
        
        try {
            
            Connection connection = getConexion();
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet resultSet = ps.executeQuery();
            
            while (resultSet.next()) {                
                Productos producto = new Productos();
                producto.setId(resultSet.getInt(Constantes.TBL_PRODUCTOS_ID));
                producto.setCodBarras(resultSet.getString(Constantes.TBL_PRODUCTOS_COD_BARRAS));
                producto.setNombreProducto(resultSet.getString(Constantes.TBL_PRODUCTOS_NOMBRE_PRODUCTO));
                producto.setMarca(resultSet.getString(Constantes.TBL_PRODUCTOS_MARCA));
                producto.setfVencimiento(resultSet.getDate(Constantes.TBL_PRODUCTOS_FECHA_VENC));
                producto.setPrecioSinIva(resultSet.getInt(Constantes.TBL_PRODUCTOS_PRECIO_SIN_IVA));
                producto.setIva(resultSet.getFloat(Constantes.TBL_PRODUCTOS_IVA));
                producto.setPrecioConIva(resultSet.getInt(Constantes.TBL_PRODUCTOS_PRECIO_CON_IVA));
                producto.setDescuento(resultSet.getFloat(Constantes.TBL_PRODUCTOS_DESCUENTO));
                producto.setCategoria(resultSet.getInt(Constantes.TBL_PRODUCTOS_ID_CATEG));
                producto.setIdEstado(resultSet.getInt(Constantes.TBL_PRODUCTOS_ID_ESTADO));
                producto.setValorObsequio((int)(((resultSet.getInt(Constantes.TBL_PRODUCTOS_PRECIO_CON_IVA) //Se realiza operación
                - (resultSet.getInt(Constantes.TBL_PRODUCTOS_PRECIO_CON_IVA)                   // para calcualar el valor de obsequio
                *resultSet.getFloat(Constantes.TBL_PRODUCTOS_DESCUENTO)))/10000))*1000);  // y se asigna al atributo "valorObsequio" 
                                                                                            // del objeto de clase Productos.
                invProductosPromo.add(producto);
            }
            
        } 
        catch (SQLException e) {
            
            System.out.println("Error al leer los datos de la BD " + e);
            return invProductosPromo; //quedaria vacio
        }
        finally {
            try {
                getConexion().close();
            } 
            catch (SQLException e) {
            System.err.println("Error al cerrar la conexión" + e.getMessage());                
            }
        }
        return invProductosPromo;
    }    

    @Override
    public boolean AgregarProductoEnCarrito(Pedidos pedido, Productos productoAdd/*, VistaApp vistaApp*/) {
        //En base de datos insertamos el producto correspondiente al carrito en la tabla carritos_pedidos
        String sql = "INSERT INTO " + Constantes.TBL_CARRITOS_PEDIDOS + "(" + Constantes.TBL_CARRITOS_PEDIDOS_ID_PEDIDO + ", " 
                                                                    + Constantes.TBL_CARRITOS_PEDIDOS_ID_PRODUCTO + ") VALUES (?,?)";
        try {
            Connection connection = getConexion();
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setInt(1, pedido.getId());
            ps.setInt(2, productoAdd.getId());
            ps.executeUpdate();
            
            System.out.println("==> El producto seleccionado se ha agregado exitosamente al carrito");
            
        } 
        catch (SQLException e) {
        	System.err.println("Error al insertar el producto " + e.getMessage());
            return false;
        }
        finally {
            try {
                getConexion().close();
            } 
            catch (SQLException e) {
            	System.err.println("Error al cerrar la conexión" + e.getMessage());                
            }
        }
        return true;
    }
    
    @Override
    public ArrayList<Productos> inventarioProductosEnCarrito(Pedidos pedido/*, VistaApp vistaApp*/) {
        // EN base de datos consultamos todos los productos existentes en el carrito      
        ArrayList<Productos> invProductosEnCarrito = new ArrayList<>(); // Se crea arraylist donde agregamos objetos de tipo Productos con sus atributos correspondientes traidos de la Base de datos
        
        String sql = "SELECT " 
                + Constantes.TBL_PRODUCTOS + "." + Constantes.TBL_PRODUCTOS_ID + ", " 
                + Constantes.TBL_PRODUCTOS + "." + Constantes.TBL_PRODUCTOS_COD_BARRAS + ", "
                + Constantes.TBL_PRODUCTOS + "." + Constantes.TBL_PRODUCTOS_NOMBRE_PRODUCTO + ", " 
                + Constantes.TBL_PRODUCTOS + "." + Constantes.TBL_PRODUCTOS_MARCA + ", " 
                + Constantes.TBL_PRODUCTOS + "." + Constantes.TBL_PRODUCTOS_FECHA_VENC + ", " 
                + Constantes.TBL_PRODUCTOS + "." + Constantes.TBL_PRODUCTOS_PRECIO_SIN_IVA + ", "
                + Constantes.TBL_PRODUCTOS + "." + Constantes.TBL_PRODUCTOS_IVA + ", " 
                + Constantes.TBL_PRODUCTOS + "." + Constantes.TBL_PRODUCTOS_PRECIO_CON_IVA + ", "
                + Constantes.TBL_PRODUCTOS + "." + Constantes.TBL_PRODUCTOS_DESCUENTO + ", " 
                + Constantes.TBL_PRODUCTOS + "." + Constantes.TBL_PRODUCTOS_ID_CATEG + ", "
                + Constantes.TBL_PRODUCTOS + "." + Constantes.TBL_PRODUCTOS_ID_ESTADO 
                + " FROM " + Constantes.TBL_PRODUCTOS 
                + " JOIN " + Constantes.TBL_CARRITOS_PEDIDOS + " ON " 
                + Constantes.TBL_CARRITOS_PEDIDOS + "." + Constantes.TBL_CARRITOS_PEDIDOS_ID_PRODUCTO 
                + " = " + Constantes.TBL_PRODUCTOS + "." + Constantes.TBL_PRODUCTOS_ID 
                + " WHERE " + Constantes.TBL_CARRITOS_PEDIDOS + "." + Constantes.TBL_CARRITOS_PEDIDOS_ID_PEDIDO 
                + " = " + pedido.getId();
        
        try {
            
            Connection connection = getConexion();
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet resultSet = ps.executeQuery();
            
            while (resultSet.next()) {                
                Productos producto = new Productos();
                producto.setId(resultSet.getInt(Constantes.TBL_PRODUCTOS_ID));
                producto.setCodBarras(resultSet.getString(Constantes.TBL_PRODUCTOS_COD_BARRAS));
                producto.setNombreProducto(resultSet.getString(Constantes.TBL_PRODUCTOS_NOMBRE_PRODUCTO));
                producto.setMarca(resultSet.getString(Constantes.TBL_PRODUCTOS_MARCA));
                producto.setfVencimiento(resultSet.getDate(Constantes.TBL_PRODUCTOS_FECHA_VENC));
                producto.setPrecioSinIva(resultSet.getInt(Constantes.TBL_PRODUCTOS_PRECIO_SIN_IVA));
                producto.setIva(resultSet.getFloat(Constantes.TBL_PRODUCTOS_IVA));
                producto.setPrecioConIva(resultSet.getInt(Constantes.TBL_PRODUCTOS_PRECIO_CON_IVA));
                producto.setDescuento(resultSet.getFloat(Constantes.TBL_PRODUCTOS_DESCUENTO));
                producto.setCategoria(resultSet.getInt(Constantes.TBL_PRODUCTOS_ID_CATEG));
                producto.setIdEstado(resultSet.getInt(Constantes.TBL_PRODUCTOS_ID_ESTADO));
                producto.setValorObsequio((int)(((resultSet.getInt(Constantes.TBL_PRODUCTOS_PRECIO_CON_IVA) //Se realiza operación
                - (resultSet.getInt(Constantes.TBL_PRODUCTOS_PRECIO_CON_IVA)                   // para calcualar el valor de obsequio
                *resultSet.getFloat(Constantes.TBL_PRODUCTOS_DESCUENTO)))/10000))*1000);  // y se asigna al atributo "valorObsequio" 
                                                                                            // del objeto de clase Productos.
                invProductosEnCarrito.add(producto);
            }
            
        } 
        catch (SQLException e) {
            
        	System.out.println("Error al leer los datos de la BD " + e);
            return invProductosEnCarrito; //quedaria vacio
        }
        finally {
            try {
                getConexion().close();
            } 
            catch (SQLException e) {
            	System.out.println("Error al cerrar la conexión" + e.getMessage());                
            }
        }
        return invProductosEnCarrito;
    }
    
    @Override
    public CarritosPedidos consultaproductoSacarDelCarrito (Pedidos pedido, Productos productoRetirar/*, VistaApp vistaApp*/) {
        //En base de datos consultamos la información necesaria "incluido el ID", y esta información la asignamos a un objeto de
        // clase CarritosPedidos, con el fin de usar esta información para poder eliminar el producto del carrito que el usuario 
        //seleccione
        CarritosPedidos productoRetirarDelCarrito = new CarritosPedidos(); 
        
        String sql = "SELECT * FROM " + Constantes.TBL_CARRITOS_PEDIDOS + 
                     " WHERE " + Constantes.TBL_CARRITOS_PEDIDOS_ID_PEDIDO + " = " + pedido.getId() + " AND "
                    + Constantes.TBL_CARRITOS_PEDIDOS_ID_PRODUCTO + " = " + productoRetirar.getId() + " ORDER BY ID DESC LIMIT 1";

        try {
            
            Connection connection = getConexion();
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet resultSet = ps.executeQuery();
            
            while (resultSet.next()) {                
                
                productoRetirarDelCarrito.setId(resultSet.getInt(Constantes.TBL_CARRITOS_PEDIDOS_ID));
                productoRetirarDelCarrito.setIdPedido(resultSet.getInt(Constantes.TBL_CARRITOS_PEDIDOS_ID_PEDIDO));
                productoRetirarDelCarrito.setIdProducto(resultSet.getInt(Constantes.TBL_CARRITOS_PEDIDOS_ID_PRODUCTO));              
            }
            
        } 
        catch (SQLException e) {
            
        	System.out.println("Error al leer los datos de la BD " + e);
            return productoRetirarDelCarrito; //quedaria vacio
        }
        finally {
            try {
                getConexion().close();
            } 
            catch (SQLException e) {
            	System.out.println("Error al cerrar la conexión" + e.getMessage());                
            }
        }
        return productoRetirarDelCarrito;  
    }
    
    @Override
    public boolean sacarProductoDeCarrito(Pedidos pedido, Productos productoRetirar/*, VistaApp vistaApp*/) {
    //En la base de datos eliminamos el producto seleccionado por el usuario    
        CarritosPedidos productoRetirarDelCarrito = consultaproductoSacarDelCarrito(pedido, productoRetirar/*, vistaApp*/);
        
        String sql = "DELETE FROM " + Constantes.TBL_CARRITOS_PEDIDOS + " WHERE " 
                + Constantes.TBL_CARRITOS_PEDIDOS_ID + " = " + productoRetirarDelCarrito.getId();
        try {
            Connection connection = getConexion();
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.executeUpdate();
            
            System.out.println("==> El producto seleccionado se ha sacado del carrito exitosamente!");
            
        } 
        catch (SQLException e) {
        	System.out.println("Error al eliminar  el producto " + e.getMessage());
            return false;
        }
        finally {
            try {
                getConexion().close();
            } 
            catch (SQLException e) {
            	System.out.println("Error al cerrar la conexión" + e.getMessage());                
            }
        }
        return true;
    }
}
