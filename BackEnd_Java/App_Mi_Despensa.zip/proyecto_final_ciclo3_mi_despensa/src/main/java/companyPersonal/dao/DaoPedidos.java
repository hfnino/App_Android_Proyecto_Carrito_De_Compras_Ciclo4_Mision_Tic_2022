package companyPersonal.dao;

import companyPersonal.modelos.Pedidos;
import companyPersonal.modelos.Usuarios;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class DaoPedidos extends Conexion implements InterfazDaoPedidos {

    @Override
    public boolean crearPedido(Usuarios usuario/*, VistaApp vistaApp*/) {
        //insertamos en la base de datos los datos necesarios para crear un nuevo pedido
        String sql = "INSERT INTO " + Constantes.TBL_PEDIDOS + "(" + Constantes.TBL_PEDIDOS_ID_USUARIO + ", "
                                                                    + Constantes.TBL_PEDIDOS_ID_ESTADO 
                                                                   + ") VALUES (?,?)";
        try {
            Connection connection = getConexion();
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setInt(1, usuario.getId());
            Integer estadoPedido = 5; //estado 5 (Abierto) por defecto
            ps.setInt(2, estadoPedido);
            ps.executeUpdate();
        
        } 
        catch (SQLException e) {
            System.out.println("Error al crear el usuario " + e.getMessage());
            return false;
        }
        finally {
            try {
                getConexion().close();
            } 
            catch (SQLException e) {
            	System.out.println( "Error al cerrar la conexión" + e.getMessage());                
            }
        }
        return true;
    }
    
    @Override
    public Pedidos consultaPedidoActual (Usuarios usuario/*, VistaApp vistaApp*/) {
        //En la base de datos consultamos el pedido mas reciente al usuario registrado
        String sql = "SELECT * FROM " + Constantes.TBL_PEDIDOS + 
                     " WHERE " + Constantes.TBL_PEDIDOS_ID_USUARIO + " = " + usuario.getId() + " ORDER BY ID DESC LIMIT 1";
        
        Pedidos pedidoActual = new Pedidos();        
        
        try {
            
            Connection connection = getConexion();
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet resultSet = ps.executeQuery();
            
            while (resultSet.next()) {                
                
                pedidoActual.setId(resultSet.getInt(Constantes.TBL_PEDIDOS_ID));
                pedidoActual.setId_usuario(resultSet.getInt(Constantes.TBL_PEDIDOS_ID_USUARIO));
                pedidoActual.setId_estado(resultSet.getInt(Constantes.TBL_PEDIDOS_ID_ESTADO));              
            }
            
        } 
        catch (SQLException e) {
            
        	System.out.println("Error al leer los datos de la BD " + e);
            return pedidoActual; //quedaria vacio
        }
        finally {
            try {
                getConexion().close();
            } 
            catch (SQLException e) {
            	System.out.println("Error al cerrar la conexión" + e.getMessage());                
            }
        }
        return pedidoActual;  
    }  
	
}
