package companyPersonal.dao;

public final class Constantes {
    
    public static final String URL="jdbc:mysql://localhost:3306/";
    public static final String DATABASE="sup_su_despensa";
    public static final String USER="root";
    public static final String PASSWORD="";
    //public static final String PASSWORD="Ciclo3Mision_Tic09";
    
    public static final String TBL_USUARIOS="usuarios";
    public static final String TBL_USUARIOS_ID="id";
    public static final String TBL_USUARIOS_CEDULA="cedula";
    public static final String TBL_USUARIOS_NOMBRE="nombre";
    public static final String TBL_USUARIOS_CORREO="correo_e";
    public static final String TBL_USUARIOS_VALOR_OBQ_ACOMU="valor_obsequios_acomulados";
    public static final String TBL_USUARIOS_ID_ESTADO="id_estado";
    
    public static final String TBL_PEDIDOS = "pedidos";
    public static final String TBL_PEDIDOS_ID = "id";
    public static final String TBL_PEDIDOS_ID_USUARIO = "id_usuario";
    public static final String TBL_PEDIDOS_ID_ESTADO = "id_estado";    
    
    public static final String TBL_PRODUCTOS = "productos";
    public static final String TBL_PRODUCTOS_ID = "id";
    public static final String TBL_PRODUCTOS_COD_BARRAS = "cod_barras";
    public static final String TBL_PRODUCTOS_NOMBRE_PRODUCTO = "nombre_producto";
    public static final String TBL_PRODUCTOS_MARCA = "marca";
    public static final String TBL_PRODUCTOS_FECHA_VENC = "fecha_venc";
    public static final String TBL_PRODUCTOS_PRECIO_SIN_IVA = "precio_sin_iva";
    public static final String TBL_PRODUCTOS_IVA = "iva";
    public static final String TBL_PRODUCTOS_PRECIO_CON_IVA = "precio_con_iva";
    public static final String TBL_PRODUCTOS_DESCUENTO = "descuento";
    public static final String TBL_PRODUCTOS_ID_CATEG = "id_categoria";
    public static final String TBL_PRODUCTOS_ID_ESTADO = "id_estado";
    
    public static final String TBL_CARRITOS_PEDIDOS = "carritos_pedidos";
    public static final String TBL_CARRITOS_PEDIDOS_ID = "id";
    public static final String TBL_CARRITOS_PEDIDOS_ID_PEDIDO = "id_pedido";
    public static final String TBL_CARRITOS_PEDIDOS_ID_PRODUCTO = "id_producto";
    
}

