package companyPersonal.dao;

//package com.ejm.semana6.reto5.dao;
import companyPersonal.modelos.Usuarios;
//import com.ejm.semana6.reto5.modelos.Usuarios;
//import com.ejm.semana6.reto5.vistas.VistaApp;
import java.util.ArrayList;

public interface InterfazDaoUsuarios { 
    
    public Usuarios verUsuario(Usuarios usuarioAConsultar/*, VistaApp vistaApp*/); // En SQL sería un Select 
    
    public ArrayList<Usuarios> verUsuarios(/*VistaApp vistaApp*/); // En SQL sería un Select  
    
    public boolean crearUsuario(Usuarios usuario/*, VistaApp vistaApp*/); // En SQL sería un Insert
    
    public boolean actualizarInfoUsuarioObsequios(Usuarios usuario, Integer totalObsequios/*, VistaApp vistaApp*/);

}
