package companyPersonal.dao;

import companyPersonal.modelos.Pedidos;
import companyPersonal.modelos.Usuarios;

public interface InterfazDaoPedidos {

    public boolean crearPedido(Usuarios usuario/*, VistaApp vistaApp*/);
    
    public Pedidos consultaPedidoActual (Usuarios usuario/*, VistaApp vistaApp*/);
    
}
