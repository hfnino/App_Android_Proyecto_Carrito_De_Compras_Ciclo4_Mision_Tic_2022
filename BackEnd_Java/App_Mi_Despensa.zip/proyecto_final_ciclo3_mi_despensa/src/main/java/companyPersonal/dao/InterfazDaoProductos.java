package companyPersonal.dao;

import companyPersonal.modelos.CarritosPedidos;
import companyPersonal.modelos.Pedidos;
import companyPersonal.modelos.Productos;

import java.util.ArrayList;

	
public interface InterfazDaoProductos {
		
    public ArrayList<Productos> inventarioProductosTipo(int tipoProductos);
    
    public ArrayList<Productos> inventarioProductosPromocion();
    
    public boolean AgregarProductoEnCarrito(Pedidos pedido, Productos productoAdd);
    
    public ArrayList<Productos> inventarioProductosEnCarrito(Pedidos pedido);
    
    public CarritosPedidos consultaproductoSacarDelCarrito (Pedidos pedido, Productos productoRetirar);
    
    public boolean sacarProductoDeCarrito(Pedidos pedido, Productos productoRetirar);
  
}
