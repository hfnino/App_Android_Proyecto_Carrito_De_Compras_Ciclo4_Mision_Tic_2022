package companyPersonal.modelos;

public class Proveedor {
    
    private String marca;
    private Integer categoria;

    public Proveedor(){ // Creamos constructor para poder crear instancias de esta clase sin necesidad de ponerle argumentos
        
    }
    
    public Proveedor(String marca, Integer categoria) { // Creamos constructor para inicializar las variables correspondientes
        this.marca = marca;
        this.categoria = categoria;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public Integer getCategoria() {
        return categoria;
    }

    public void setCategoria(Integer categoria) {
        this.categoria = categoria;
    }
}
