package companyPersonal.modelos;
//package com.ejm.semana6.reto5.modelos;

//import java.util.Scanner;
//import javax.swing.JOptionPane;

public class Usuarios {  //Creamos clase Usuarios 
    //Declaramos las variables necesarias
    private Integer id;
    private Integer cedula;
    private String nombre;
    private String correoE;
    private Integer valorAcomuladoObsequios;
    private Integer estado;
    //private Scanner entrada = new Scanner(System.in);

    public Usuarios(){ // Creamos constructor para poder crear instancias de esta clase sin necesidad de ponerle argumentos
        
    }
    // Creamos constructor para inicializar las variables correspondientes y usamos sobrecarga de constructores
    public Usuarios(Integer cedula, String nombre, String correoE, Integer valorAcomuladoObsequios) {
        this.cedula = cedula;
        this.nombre = nombre;
        this.correoE = correoE;
        this.valorAcomuladoObsequios = valorAcomuladoObsequios;
        this.estado = 1;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    
    public Integer getCedula() {
        return cedula;
    }

    public void setCedula(Integer cedula) {
        this.cedula = cedula;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCorreoE() {
        return correoE;
    }

    public void setCorreoE(String correoE) {
        this.correoE = correoE;
    }

    public Integer getValorAcomuladoObsequios() {
        return valorAcomuladoObsequios;
    }

    public void setValorAcomuladoObsequios(Integer valorAcomuladoObsequios) {
        this.valorAcomuladoObsequios = valorAcomuladoObsequios;
    }
    
    public Integer getEstado() {
        return estado;
    }

    public void setEstado(Integer estado) {
        this.estado = estado;
    }
    
    @Override  //sobreescribismos el metodo toString de la clase Objet
    public String toString(){
        return  "\nCodígo de Usuario ID: " + getId() +
                "\nNúmero de cedula: " + getCedula() +
                "\nNombre: " + getNombre() +
                "\nCorreo electronico: " + getCorreoE() +
                "\nValor actual acomulado de Obsequios: " + getValorAcomuladoObsequios() + 
        		"\nEstado: " + getEstado() + "\n";
    }
  
}