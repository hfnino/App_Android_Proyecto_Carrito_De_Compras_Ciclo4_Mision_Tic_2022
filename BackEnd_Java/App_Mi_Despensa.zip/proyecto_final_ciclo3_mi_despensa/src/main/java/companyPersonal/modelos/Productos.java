package companyPersonal.modelos;


//Importamos librerias necesarias
//import java.time.LocalDate;
//import java.time.format.DateTimeFormatter;
import java.sql.Date;
//import java.util.ArrayList;
//import java.util.Scanner;

public class Productos extends Proveedor{  
    
    //Declaramos las variables necesarias
    private Integer id;
    private String codBarras;
    private String nombreProducto;
    private Date fVencimiento;
    private Integer precioSinIva;
    private Float iva;
    private Integer precioConIva;
    private Float descuento;
    private Integer idEstado;
    private Integer valorObsequio;
    //private Scanner entrada = new Scanner(System.in);


    public Productos(){ // Creamos constructor para poder crear instancias de esta clase sin necesidad de ponerle argumentos
        
    }
    // Creamos constructor para inicializar las variables correspondientes
    public Productos(String codBarras, String nombreProducto, String marca, Date fVencimiento, Integer precioConIva, Float descuento, Integer categoria) {
        super(marca, categoria);
        this.codBarras = codBarras;
        this.nombreProducto = nombreProducto;
        this.fVencimiento = fVencimiento;
        this.precioConIva = precioConIva;
        this.descuento = descuento;
        valorObsequio = (int)(((precioConIva - (precioConIva*descuento))/10000))*1000;
    }
    // Creamos constructor para inicializar las variables correspondientes y usamos sobrecarga de constructores
    public Productos(String codBarras, String nombreProducto, String marca, Integer precioConIva, Float descuento, Integer categoria) {
        super(marca, categoria);
        this.codBarras = codBarras;
        this.nombreProducto = nombreProducto;
        this.precioConIva = precioConIva;
        this.descuento = descuento;
        valorObsequio = (int)(((precioConIva - (precioConIva*descuento))/10000))*1000;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
    
    public String getCodBarras() { //getter de la variable correspondiente
        return codBarras;
    }

    public void setCodBarras(String codBarras) { //Setter de la variable correspondiente
        this.codBarras = codBarras;
    }

    public String getNombreProducto() {  //getter de la variable correspondiente
        return nombreProducto;
    }

    public void setNombreProducto(String nombreProducto) {   //Setter de la variable correspondiente
        this.nombreProducto = nombreProducto;
    }

    public Date getfVencimiento() {   //getter de la variable correspondiente
        return fVencimiento;
    }

    public void setfVencimiento(Date fVencimiento) { //Setter de la variable correspondiente
        this.fVencimiento = fVencimiento;
    }

    public Integer getPrecioSinIva() {
        return precioSinIva;
    }

    public void setPrecioSinIva(Integer precioSinIva) {
        this.precioSinIva = precioSinIva;
    }

    public Float getIva() {
        return iva;
    }

    public void setIva(Float iva) {
        this.iva = iva;
    }

    public Integer getPrecioConIva() {  //getter de la variable correspondiente
        return precioConIva;
    }

    public void setPrecioConIva(Integer precioConIva) { //Setter de la variable correspondiente
        this.precioConIva = precioConIva;
    }

    public Float getDescuento() { //getter de la variable correspondiente
        return descuento;
    }

    public void setDescuento(Float descuento) { //Setter de la variable correspondiente
        this.descuento = descuento;
    }

    public Integer getValorObsequio() {   //getter de la variable correspondiente
        return valorObsequio;
    }

    public void setValorObsequio(Integer valorObsequio) { //Setter de la variable correspondiente
        this.valorObsequio = valorObsequio;
    }

    public Integer getIdEstado() {
        return idEstado;
    }

    public void setIdEstado(Integer idEstado) {
        this.idEstado = idEstado;
    }
}
