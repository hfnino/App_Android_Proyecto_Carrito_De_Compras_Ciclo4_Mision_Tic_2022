package companyPersonal.controladores;

import companyPersonal.dao.InterfazDaoUsuarios;
import companyPersonal.dao.DaoPedidos;
import companyPersonal.dao.DaoProductos;
import companyPersonal.dao.DaoUsuarios;
import companyPersonal.dao.InterfazDaoPedidos;
import companyPersonal.dao.InterfazDaoProductos;
import companyPersonal.modelos.Pedidos;
import companyPersonal.modelos.Productos;
import companyPersonal.modelos.Usuarios;
import java.io.Serializable;
import java.util.ArrayList;

//import java.util.ArrayList;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
//import javax.swing.JOptionPane;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
//import javax.faces.view.ViewScoped;
//import com.ejm.semana6.reto5.vistas.JFrameInicioApp;

@ManagedBean (name="controladorUsuariosBeam") // Con estas lineas, declaramos el codigo de este archivo .java 
@SessionScoped							// como tipo bean para conectar a las paginas xhtml del FrontEnd
//@ViewScoped

public class ControladorUsuariosBeam implements Serializable {
  
	private static final long serialVersionUID = -417936955681734012L;
	  
	private String newCc = "";
	private Integer newNumCc;
	private String newNombre = "";
	private String newCorreoE = "";
	private Usuarios consultaUsuario = new Usuarios();
	private Pedidos pedido;
	private String textoTipoProductos;
	private ArrayList<Productos> invenProductosTipo = new ArrayList<Productos>();
	private ArrayList<Productos> invProductosEnCarrito = new ArrayList<Productos>();
	private InterfazDaoProductos daoProductos = new DaoProductos();
	private InterfazDaoUsuarios daoUsuarios = new DaoUsuarios();
	private InterfazDaoPedidos daoPedidos = new DaoPedidos();
	private String msjes[] = new String[5]; // Creamos un array de String de 5 elementos para trabajar con mensajes y mostrarlos en las vistas que lo requieran
	private int cantidadProductosEliminadosCarrito = 0;
	private Double precioTotalPagar = 0.0;
	private Integer totalObsequios = 0;
	
    public String getNewCc() {
		return newCc;
	}

	public void setNewCc(String newCc) {
		this.newCc = newCc;
	}

	public String getNewNombre() {
		return newNombre;
	}

	public void setNewNombre(String newNombre) {
		this.newNombre = newNombre;
	}

	public String getNewCorreoE() {
		return newCorreoE;
	}

	public void setNewCorreoE(String newCorreoE) {
		this.newCorreoE = newCorreoE;
	}
	
	public Usuarios getConsultaUsuario() {
		return consultaUsuario;
	}

	public void setConsultaUsuario(Usuarios consultaUsuario) {
		this.consultaUsuario = consultaUsuario;
	}
	
	public Pedidos getPedido() {
		return pedido;
	}

	public void setPedido(Pedidos pedido) {
		this.pedido = pedido;
	}
	
	public String getTextoTipoProductos() {
		return textoTipoProductos;
	}

	public void setTextoTipoProductos(String textoTipoProductos) {
		this.textoTipoProductos = textoTipoProductos;
	}

	public ArrayList<Productos> getInvenProductosTipo() {
		return invenProductosTipo;
	}

	public void setInvenProductosTipo(ArrayList<Productos> invenProductosTipo) {
		this.invenProductosTipo = invenProductosTipo;
	}

	public InterfazDaoProductos getDaoProductos() {
		return daoProductos;
	}

	public void setDaoProductos(InterfazDaoProductos daoProductos) {
		this.daoProductos = daoProductos;
	}

	public String[] getMsjes() {
		return msjes;
	}

	public void setMsjes(String[] msjes) {
		this.msjes = msjes;
	}

	public ArrayList<Productos> getInvProductosEnCarrito() {
		return invProductosEnCarrito;
	}

	public void setInvProductosEnCarrito(ArrayList<Productos> invProductosEnCarrito) {
		this.invProductosEnCarrito = invProductosEnCarrito;
	}

	
	public Double getPrecioTotalPagar() {
		return precioTotalPagar;
	}

	public void setPrecioTotalPagar(Double precioTotalPagar) {
		this.precioTotalPagar = precioTotalPagar;
	}

	public Integer getTotalObsequios() {
		return totalObsequios;
	}

	public void setTotalObsequios(Integer totalObsequios) {
		this.totalObsequios = totalObsequios;
	}

	public String validarUsuario() {
    	
		//System.out.println("la cedula que ingreso es => "+ newCc);   //Prueba de Escritorio
		//System.out.println("El nombre completo ingresado es => "+ newNombre); //Prueba de Escritorio
		//System.out.println("El correo electronico  ingresado es => "+ newCorreoE); //Prueba de Escritorio
	    
		FacesContext context = FacesContext.getCurrentInstance();
		
		String mensajes = "";
		
        if (newCc.equals("")) {
			mensajes = "el campo de Cedula es obligatorio";
			context.addMessage("validacionCc", new FacesMessage(FacesMessage.SEVERITY_ERROR, mensajes, mensajes)); //validacionCc es el id que asocia el mensaje al mensaje en el index.xhtml que tiene el for="validaciinCc"
			return "index.xhtml";
        }
        
		if (newNombre.equals("")) {
			mensajes = "el campo 'Nombre Completo' es oblogatorio";
			context.addMessage("validacionNombreCompleto", new FacesMessage(FacesMessage.SEVERITY_FATAL, mensajes, mensajes));
			return "index.xhtml";
		}
		
		if (newCorreoE.equals("")) {
			mensajes = "el campo 'Correo Electronico' es oblogatorio";
			context.addMessage("validacionCorreoE", new FacesMessage(FacesMessage.SEVERITY_WARN, mensajes, mensajes));
			return "index.xhtml";
		}
			
	    while(true){
	        try { //Se valida que los valores ingresados sean correctos
	           newNumCc = Integer.valueOf(newCc); //se guarda el numero de cedula ingresada por el usuario en formato Integer
	                                                                        //desde el formulario de registo de la Interfaz Grafica
	           break;
	        }
	        catch (Exception e) {
				mensajes = " ==> Error Catch: Usted ha ingresado valores no permitidos en el campo Cedula, intentelo nuevamente." + e.getMessage();
				//newCc = "";
				context.addMessage("validacionCc", new FacesMessage(FacesMessage.SEVERITY_ERROR, mensajes, mensajes));
				return "index.xhtml";
	        }
	    }
	              
	    Usuarios usuario = new Usuarios(newNumCc, newNombre, newCorreoE, 0); //creamos instancia de la clase Usuarios y enviamos valores
	                                                                      //a los atributos correspondientes
	    
	    System.out.println("Prueba de Escritorio 1 - El usuario  ingresado en el form es:  " + usuario);  //Prueba de Escritorio
	    
	    //InterfazDaoUsuarios daoUsuarios = new DaoUsuarios();
	    consultaUsuario = daoUsuarios.verUsuario(usuario); // En la base de datos MySQL se consulta los datos ingresados 
	                                                                //para validar si el usuario existe o no existe
 
	    System.out.println("Prueba de Escritorio 2 - El usuario  consultado en la BD es:  " + consultaUsuario);  //Prueba de Escritorio
	    
		if (consultaUsuario.getCedula() != null && consultaUsuario.getCedula() == 999999999) {
			System.out.println("Prueba de Escritorio 4,1,1 => El usuario consultado es => " + consultaUsuario.getCedula()); // Prueba de Escritorio
			mensajes = "===> Error al conectar a la base de datos, por favor informe al administrador del sistema";
			context.addMessage("validacionCc", new FacesMessage(FacesMessage.SEVERITY_WARN, mensajes, mensajes));
			return "index.xhtml";
		}
		
		if (consultaUsuario.getCorreoE() != null && usuario.getCorreoE().equals(consultaUsuario.getCorreoE())) {
			mensajes = " La conexión a la base de datos fue exitosa!  =)";
			String mensajeInfoUsuario = " ==> El usuario con el correo '" + usuario.getCorreoE() + "' ya se encuentra registrado en la base de datos con los siguientes datos: ";  
			System.out.println(mensajeInfoUsuario); // Prueba de Escritorio
			context.addMessage("infoConexion", new FacesMessage(FacesMessage.SEVERITY_INFO, mensajes, mensajes));	
			context.addMessage("infoUsuario", new FacesMessage(FacesMessage.SEVERITY_WARN, mensajeInfoUsuario, mensajeInfoUsuario));
			return "index.xhtml";
		}
		
		if (consultaUsuario.getCedula() != null && consultaUsuario.getCedula() != 999999999) {
			mensajes = " La conexión a la base de datos fue exitosa!  =)";
			String mensajeInfoUsuario = " ==> El usuario con el número de cedula '" + usuario.getCedula() + "' ya se encuentra registrado en la base de datos con los siguientes datos: ";  
			System.out.println(mensajeInfoUsuario); // Prueba de Escritorio
			context.addMessage("infoConexion", new FacesMessage(FacesMessage.SEVERITY_INFO, mensajes, mensajes));	
			context.addMessage("infoUsuario", new FacesMessage(FacesMessage.SEVERITY_WARN, mensajeInfoUsuario, mensajeInfoUsuario));
			return "index.xhtml";
		}
		
	    if(consultaUsuario.getCedula() == null){
		//else {
	    	
		    //System.out.println("\n Prueba de Escritorio => El usuario consultado es => " + consultaUsuario.getCedula()); // Prueba de Escritorio
	    	
	        daoUsuarios.crearUsuario(usuario); 
	        consultaUsuario = daoUsuarios.verUsuario(usuario/*, vistaApp*/); // En la base de datos MySQL se consulta los datos ingresados
	                                                                //para retornar el usuario creado junto con el ID asignado.
	        consultaUsuario.setEstado(2);
	        //return consultaUsuario;
	        System.out.println("\n Prueba de Escritorio 4,5 => El nuevo usuario creado fue => "+ consultaUsuario);
	        
	       //return "pagina_principal.xhtml";
	        
			mensajes = " La conexión a la base de datos fue exitosa!  =)"; 
			String mensajeInfoUsuario = " ==> El usuario con el número de cedula '" + usuario.getCedula() + 
					"' no se encontraba registrado en la base de datos, por tanto, el usuario " +
                    "con la información ingresada fue creado con exito! ";
			
			System.out.println(mensajeInfoUsuario);
			
			context.addMessage("infoConexion2", new FacesMessage(FacesMessage.SEVERITY_INFO, mensajes, mensajes));	
			context.addMessage("infoUsuario2", new FacesMessage(FacesMessage.SEVERITY_INFO, mensajeInfoUsuario, mensajeInfoUsuario));
			return "index.xhtml";
   
	    }
	    
	    return "reenvio_menu_principal.xhtml";
	    
	}
	
	public String menuPrincipal() {
		consultaUsuario.setEstado(1);
		//InterfazDaoPedidos daoPedidos = new DaoPedidos();
        daoPedidos.crearPedido(consultaUsuario);
        pedido = daoPedidos.consultaPedidoActual(consultaUsuario);
        
        System.out.println("El pedido creado fue => " + pedido.getId()); // Prueba de Escritorio
		
		return "reenvio_menu_principal.xhtml";
	}
	
	public String cerrarSesion() {
		consultaUsuario.setCedula(null);
		consultaUsuario.setNombre(null);
		consultaUsuario.setCorreoE(null);
		consultaUsuario.setValorAcomuladoObsequios(0);
		consultaUsuario.setEstado(0);
		
		return "reenvio_index.xhtml";
		
	}
	
	public String verProductosPorTipo(int tipoProductos) {

		System.out.println("El tipo de productos seleccionado es => " + tipoProductos); //Prueba de Escritorio
		
        if(tipoProductos == 4) {
        	
        	textoTipoProductos = "con Promociones";
        	
        	invenProductosTipo = daoProductos.inventarioProductosPromocion();     
        	
        }
        else {
			if(tipoProductos == 1){ 
	        	textoTipoProductos = "Comestibles";
	        }
			
	        if(tipoProductos == 2){ 
	        	textoTipoProductos = "Liquidos";
	        }
	        
	        if(tipoProductos == 3){ 
	        	textoTipoProductos = "Aseo";
	        }
	        
	        invenProductosTipo = daoProductos.inventarioProductosTipo(tipoProductos); // se consulta en la base de datos los productos correspondientes
        }        																     // asociados al tipo de producto seleccionado
        
        

        
        /*   Bloque de codigo para prueba de Escritorio

        for(int i = 0; i < invenProductosTipo.size(); i++){ // Con ayuda del for, le mostramos al usuario la lista de todos los 
            //productos existentes en inventario asociados al tipo de productos

        	String datos[] = new String[9]; // se crea array de Strings a de 9 elementos, y a cada elemento se le asigna el valor 
			        //correspondiente al objeto del ArrayLists de objetos de tipo prodctos
			datos[0] = String.valueOf(i+1);
			datos[1] = invenProductosTipo.get(i).getCodBarras();
			datos[2] = invenProductosTipo.get(i).getNombreProducto();
			datos[3] = invenProductosTipo.get(i).getMarca();
			datos[4] = String.valueOf(invenProductosTipo.get(i).getfVencimiento());
			datos[5] = String.valueOf(invenProductosTipo.get(i).getPrecioConIva());
			datos[6] = String.valueOf(invenProductosTipo.get(i).getPrecioConIva()*invenProductosTipo.get(i).getDescuento());
			datos[7] = String.valueOf(invenProductosTipo.get(i).getPrecioConIva() - (invenProductosTipo.get(i).getPrecioConIva()*invenProductosTipo.get(i).getDescuento()));
			datos[8] = String.valueOf(invenProductosTipo.get(i).getValorObsequio());
			
			
			System.out.println(datos[0]);
			System.out.println(datos[1]);
			System.out.println(datos[2]);
			System.out.println(datos[3]);
			System.out.println(datos[4]);
			System.out.println(datos[5]);
			System.out.println(datos[6]);
			System.out.println(datos[7]);
			System.out.println(datos[8] + "\n");	
		}
		
		*/
        
		return "reenvio_lista_productos.xhtml";
		
	}
	
	public String linkImgProductos(int idProducto) {
		
		String linkImgProd = "img/Productos_Comestibles/img_comestibles_defecto_1000x1500.png";
		
		if(idProducto == 1) {
			linkImgProd = "img/Productos_Comestibles/Arroz_Supremo_5kg_1000x1500.png";
		}
		
		if(idProducto == 2) {
			linkImgProd = "img/Productos_Comestibles/chocolate_corona_1000x1500.png";
		}
		
		if(idProducto == 3) {
			linkImgProd = "img/Productos_Comestibles/Queso_Colanta_2kg_1000x1500.png";
		}	
		
		if(idProducto == 4) {
			linkImgProd = "img/Productos_Comestibles/salchicon_zenu_1000x15000.png";
		}	

		return linkImgProd;
	}
	
	public String addProductoEnCarrito(Productos productoAdd) {
		
		daoProductos.AgregarProductoEnCarrito(pedido, productoAdd);
		
		String mensajeAdd = "";

		mensajeAdd = " El producto fue agregado al carrito  =)";
		
		FacesContext context = FacesContext.getCurrentInstance();

		context.addMessage("infoConfirm", new FacesMessage(FacesMessage.SEVERITY_INFO, "Confirmado", mensajeAdd));	

		return "lista_productos.xhtml";
	}
	
	public String cantidadProductosCarrito() {
		
		invProductosEnCarrito = daoProductos.inventarioProductosEnCarrito(pedido);
		
		String mensaje = "";
		
		FacesContext context = FacesContext.getCurrentInstance();
		
        if(invProductosEnCarrito.size() == 0){
            
    		mensaje = "Actualmente, el carrito esta vacio";
        	System.out.println(mensaje);
    		context.addMessage("infoCant", new FacesMessage(FacesMessage.SEVERITY_WARN, "Datos de Interes:", mensaje));	
            return "menu_principal.xhtml";
           
        }
        
        Integer cantidadProductosComestibles = 0; // Declaramos variables para ser usadas como contadores
        Integer cantidadProductosLiquidos = 0; // Declaramos variables para ser usadas como contadores
        Integer cantidadProductosAseo = 0; // Declaramos variables para ser usadas como contadores
        
        for(int i = 0; i < invProductosEnCarrito.size(); i++){ // Con ayuda del for, recorremos la el array list y usamos los contadores tenienndo en cuenta la categoria del producto
            
            if(invProductosEnCarrito.get(i).getCategoria() == 1){
                cantidadProductosComestibles += 1;
            }
            if(invProductosEnCarrito.get(i).getCategoria() == 2){
                cantidadProductosLiquidos += 1;
            }  
            if(invProductosEnCarrito.get(i).getCategoria() == 3){
                cantidadProductosAseo += 1;
            }    
        }
        
        mensaje = "Actualmente, en el carrito hay: \n\n"
        		+ (cantidadProductosComestibles + cantidadProductosLiquidos + cantidadProductosAseo) + " Productos en total, de los cuales hay "
                + cantidadProductosComestibles + " Productos Comestibles, \n"
                + cantidadProductosLiquidos + " Productos Liquidos y \n"
                + cantidadProductosAseo + " Productos de Aseo\n";
                
                
		context.addMessage("infoCant", new FacesMessage(FacesMessage.SEVERITY_WARN, "Datos de Interes:", mensaje));	
        
        return "menu_principal.xhtml";

	}
	
	public String verProductosEnCarritoCompras() {
		
		textoTipoProductos = "actualmente en el carrito de compras";
		
		String mensaje = "";
		
		FacesContext context = FacesContext.getCurrentInstance();
		
		invProductosEnCarrito = daoProductos.inventarioProductosEnCarrito(pedido);
		
        if(invProductosEnCarrito.size() == 0){
            
    		mensaje = "Actualmente, el carrito de compras esta vacio";
        	System.out.println(mensaje);
    		context.addMessage("infoProductosEnCarrito", new FacesMessage(FacesMessage.SEVERITY_WARN, "Datos de Interes:", mensaje));	
            return "menu_principal.xhtml";
           
        }
       
        return "reenvio_lista_productos_en_carrito.xhtml";
	}
	
	
    public String cantidadProductosRepetidosCarrito(){
    	
		invProductosEnCarrito = daoProductos.inventarioProductosEnCarrito(pedido);
		
		String mensaje = "";
		
		FacesContext context = FacesContext.getCurrentInstance();
		
        if(invProductosEnCarrito.size() == 0){
            
    		mensaje = "Actualmente, el carrito esta vacio, por lo que no tiene productos repetidos";
        	System.out.println(mensaje);
    		context.addMessage("infoCantProdRepetidos", new FacesMessage(FacesMessage.SEVERITY_WARN, "Datos de Interes:", mensaje));	
            return "menu_principal.xhtml";
           
        }
        
        ArrayList<Productos> productosRepetidosEnCarrito = new ArrayList<Productos>(); 
        
        for(int i = 0; i < invProductosEnCarrito.size(); i++){
            
            for(int j = i+1; j < invProductosEnCarrito.size(); j ++){
                
                if(invProductosEnCarrito.get(i).getId() == invProductosEnCarrito.get(j).getId()){
                    
                    if(productosRepetidosEnCarrito.size() == 0){

                        productosRepetidosEnCarrito.add(invProductosEnCarrito.get(i));
                        
                    }
                    else{
                    
                        for(int k = 0; k < productosRepetidosEnCarrito.size(); k++){

                            if(invProductosEnCarrito.get(i).getId() == productosRepetidosEnCarrito.get(k).getId()){
                                break;
                            }
                            else{
                                if ( k == productosRepetidosEnCarrito.size()-1){
                                    productosRepetidosEnCarrito.add(invProductosEnCarrito.get(i));
                                }
                            }
                            
                        }
                    }
                }
            }
            
        }
        
        
        System.out.println("\n Actualmente, en el carrito hay: \n\n" + productosRepetidosEnCarrito.size() + " Productos Repetidos"); 
        
		mensaje = "\n Actualmente, en el carrito hay: " + productosRepetidosEnCarrito.size() + " Productos Repetidos";
		context.addMessage("infoCantProdRepetidos", new FacesMessage(FacesMessage.SEVERITY_WARN, "Datos de Interes:", mensaje));	
        return "menu_principal.xhtml";

    }
    
	public String sacarProductosCarrito() {
		
		invProductosEnCarrito = daoProductos.inventarioProductosEnCarrito(pedido);
		
		String mensaje = "";
		
		FacesContext context = FacesContext.getCurrentInstance();
		
        if(invProductosEnCarrito.size() == 0){
            
    		mensaje = " ==> Actualmente, el carrito esta vacio";
        	System.out.println(mensaje);
    		context.addMessage("infoProductosEnCarritoRetirar", new FacesMessage(FacesMessage.SEVERITY_WARN, "Datos de Interes:", mensaje));	
            return "menu_principal.xhtml";
           
        }
        
        return "reenvio_lista_productos_en_carrito_retirar.xhtml";
	}
	
	public String retirarProductoDelCarrito(Productos productoRetirar) {
		
		daoProductos.sacarProductoDeCarrito(pedido, productoRetirar);
		
		String mensajeAdd = "";

		mensajeAdd = " El producto fue retirado del carrito  ={, por favor actualice la pagina con la tecla F5 para que el cambio se vea reflejado en la lista.";
		
		FacesContext context = FacesContext.getCurrentInstance();

		context.addMessage("infoConfirmRetiro", new FacesMessage(FacesMessage.SEVERITY_INFO, "Confirmado", mensajeAdd));	
		
		cantidadProductosEliminadosCarrito += 1;
		
		invProductosEnCarrito = daoProductos.inventarioProductosEnCarrito(pedido);

		return "lista_productos_en_carrito_retirar.xhtml";
	}
	
	public String cantidadProductosSacadosCarrito() {
		
		String mensaje = "";

		mensaje = "\n hasta el momento, Ud. ha sacado del carrito: " + cantidadProductosEliminadosCarrito + " Productos \n";
		
		FacesContext context = FacesContext.getCurrentInstance();

		context.addMessage("infoCantProdSacados", new FacesMessage(FacesMessage.SEVERITY_INFO, "Datos de Interes:", mensaje));	
		
		return "menu_principal.xhtml";
	}

	public String vistaPagar() {
		
		invProductosEnCarrito = daoProductos.inventarioProductosEnCarrito(pedido);
		
		String mensaje = "";
		
		FacesContext context = FacesContext.getCurrentInstance();
		
        if(invProductosEnCarrito.size() == 0){
            
    		mensaje = " ==> Actualmente, el carrito esta vacio, no es posible hacer el pago";
        	System.out.println(mensaje);
    		context.addMessage("infoPagarProductosEnCarrito", new FacesMessage(FacesMessage.SEVERITY_WARN, "Datos de Interes:", mensaje));	
            return "menu_principal.xhtml";
           
        }
              
		precioTotalPagar = 0.0;
		totalObsequios = 0;
		
        for(int i = 0; i < invProductosEnCarrito.size(); i++){ // Con ayuda del for, recorremos el arraylist invProductosEnCarrito
                                                 // para contabilizar y totalizar para luego
                                                 // mostrar al usuario el costo total de los productos agregados al carrito y tambien para
                                                 // mostrarle el valor total de obsequios que gana si realiza la compra
            precioTotalPagar += (invProductosEnCarrito.get(i).getPrecioConIva() - (invProductosEnCarrito.get(i).getPrecioConIva()*invProductosEnCarrito.get(i).getDescuento()));
            totalObsequios += invProductosEnCarrito.get(i).getValorObsequio();           
        }
        
		mensaje = "El valor total a pagar es: $" + precioTotalPagar + "(IVA '19%' ya incluido) y el valor total de obsequios a obtener es: $" + totalObsequios;
    	System.out.println(mensaje);
		//context.addMessage("infoPagarProductosEnCarrito", new FacesMessage(FacesMessage.SEVERITY_WARN, "Datos de Interes:", mensaje));	
        
		return "reenvio_pagar.xhtml";
		
	}
	
	public String vistaConfirmacionPago(){
		
		daoUsuarios.actualizarInfoUsuarioObsequios(consultaUsuario, totalObsequios); //En la base de datos, actualizamos el usuario con la informacion del valor de obsequios
		cantidadProductosEliminadosCarrito = 0; //Reiniciamos el contador de productos eliminados.
		daoPedidos.crearPedido(consultaUsuario); //Se crea nuevo pedido
		pedido = daoPedidos.consultaPedidoActual(consultaUsuario); //se consulta en base de datos la información 
        // completa del pedido actual para traer tambien el id correspondiente del pedido
		consultaUsuario = daoUsuarios.verUsuario(consultaUsuario); // Se consulta los datos del usuario para traer la información actualizada con el  valor acomulado de obsequios
		
		return "reenvio_confirmacion_pago.xhtml";
	}
	

}
