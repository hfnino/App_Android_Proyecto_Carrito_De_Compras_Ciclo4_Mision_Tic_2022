package co.com.personal.hnino.ejerciciosenclase;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

import co.com.personal.hnino.ejerciciosenclase.entidades.Categorias;

//Creamos un adaptador personalizado para poder desplegar la información deseada en un ListView

public class CategoriaAdapter extends BaseAdapter {//heredamos de la clase BaseAdapter que es la base de muchas de las implementaciones de adaptadores en Android.
    //La clase BaseAdapter es una clase abstracta (tiene metodos definidos en sus argumentos pero no estan implementados),
    // por lo que no puede ser instanciada de forma directa. las clases hijas que extiendan, o que implementen o que herenden una clase abstracta
    // deben implementar todos los metodos vacios (incompletos); si no se implementan todos los metodos vacios en la clase hija, entoces esa clase hija
    // debera ser tambíen declarada como una clase abstracta para que luego sea otra clase o entidad la encargada de implementarla.

    private Context context;
    private ArrayList<Categorias> dataCategorias;

    public CategoriaAdapter(Context context, ArrayList<Categorias> dataCategoria) {  // constructor de la clase CategoriaAdapter con argumentos tipo contex y ArrayList
        this.context = context;
        //En este caso no aplica configurar un atributo que relacione el layout, ya que usamos un layout personalizado que configuramos en el metodo getView.
        this.dataCategorias = dataCategoria;
    }

    @Override  //sobreescritura del metodo que fue heredado de la clase BaseAdapter
    public int getCount() {     //metodo abstracto heredado de la clase BaseAdapter que tiene como funcion decirnos cuantos items voy a mostrar o a pintar en el ListView
            if (this.dataCategorias == null){
                return 0;
            }
            else{
                return this.dataCategorias.size(); //el metodo .size() es para contar la cantidad de  elementos que tiene el ArrayList o la colección,
                                    // mientras que el metodo .length se usa para saber la cantidad de caracteres que tiene una cadena (String)
            }
    }

    @Override   //sobreescritura del metodo que fue heredado de la clase BaseAdapter
    public Object getItem(int position) {    //metodo abstracto heredado de la clase BaseAdapter que tiene como funcion retornar el item (elemento u objeto) en tipo Objet en la posición correspondiente.
        return this.dataCategorias.get(position);
    }

    @Override  //sobreescritura del metodo que fue heredado de la clase BaseAdapter
    public long getItemId(int position) {    //metodo abstracto heredado de la clase BaseAdapter que tiene como funciónretornar el atributito id del elemento tipo categoria
                                            //encontrado en la posicion position.

        return this.dataCategorias.get(position).getId();  //Si el objeto correspondiente no maneja un id, podríamos por ejemplo retornar 0
    }

    @Override  //sobreescritura del metodo que fue heredado de la clase BaseAdapter
    public View getView(int position, View viewPersonaliada, ViewGroup viewGroup) {     //metodo abstracto heredado de la clase BaseAdapter que tiene como función la creación
                                //de la vista y retorno de la misma. el argumento VieuwGroup parent, hace referencia a al layaut o a al contenedor correspondiente que
                        //piende ser por ejemplo un ListView
        if (viewPersonaliada == null){    // si esta condición es verdadera, significa que esa view no esta creada ó instanciada y portanto es necesario hacerlo. Esta situación
                        //solo se va a presentar cuando la vista no existe, si la vista ya existe, significa que la vista ya habia sido asignada y el sistema ya sabe
                        //cuales son los recursos asociados y portanto ya se podria realizar los procesos de vinculación entre la información del objeto con cada uno
                        //de los elementos del contenedor
            viewPersonaliada = LayoutInflater.from(context).inflate(R.layout.activity_item_lista_personalizada, viewGroup, false); // inflate es el metodo
                                                // que usamos para inflar o para cargar el layout personalizado que creamos y lo colocamos en el contexto actual para
                                                // representar la información.
        }

        //Categorias categoria = (Categorias) this.getItem(position); // Forma 1 para capturar el objeto tipo categoria existente en la posición correspondiente. Como getItem retorna un Pbjet, entonces
                                            // es necesario hacer un casteo a un objeto tipo Categoria

        Categorias categoria = this.dataCategorias.get(position); // Forma 2 para capturar el objeto tipo categoria existente en la posición correspondiente.
                                                            //en este caso no se neceita hacer casteo.

        TextView nombre = viewPersonaliada.findViewById(R.id.lbNombre);// el findViewById() aqui ya no funciona de manera directa por que no estamos trabajando en entorno de una Activity
                                // que tiene una vista asociada que se crea automaticamente cuando creamos un Activity ----- en este caso no se cuenta con una vista (layaut)
                                // a donde ir a consultar, pero si contamos con la vista que creamos anteriormente (viewPersonalizada), por tanto usamos esta vista, y sobre ella
                                // si podemos usar el metodo findViewById()
        TextView precio = viewPersonaliada.findViewById(R.id.lbPrecio);
        TextView valorObsequios = viewPersonaliada.findViewById(R.id.lbValorObsequios);
        TextView descripcion = viewPersonaliada.findViewById(R.id.lbDescripcion);

        nombre.setText("Id: (" + categoria.getId() + ") " + categoria.getNombre()); // Ojo... categoria.getId() retorna un int pero a las elementos de las vistas de Texto se les debe enviar String. por eso es que
                                            //usamos =>  "" + categoria.getId()   ---- el "" +  obliga a que categoria.getId() se muestre en String. como si fuera un casteo.
                                            // Cadena + cualquier cosa, el resultado es una cadena.
        descripcion.setText(categoria.getDescripcion()); //getDescripcion() retorna un String, entonces no se necesita el "" +




        return viewPersonaliada;
    }
}


