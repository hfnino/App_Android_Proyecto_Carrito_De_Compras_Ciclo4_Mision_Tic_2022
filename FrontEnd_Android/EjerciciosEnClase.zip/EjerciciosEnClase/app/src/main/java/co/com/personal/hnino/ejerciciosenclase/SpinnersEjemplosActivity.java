package co.com.personal.hnino.ejerciciosenclase;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

import co.com.personal.hnino.ejerciciosenclase.entidades.Categorias;

public class SpinnersEjemplosActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_spinners_ejemplos);

        /* ----------------------------INICIO => BLOQUE DE CODIGO PARA EL SPINNER CON ARRAY DE STRINGS ----------------------------------------------------*/


        String [] listaMediosDePago = {"Tarjeta de Credito", "Tarjeta Debito", "Nequi", "DaviPlata", "MercadoPago", "Bitcoin", "Etherium"};

        Spinner comboBox = findViewById(R.id.spinnerMediosPago);      // Una lista tipo Spinner es un campo desplegable que despliega una lista de items (como un combo).
        // Los Spinner tambien necesitan adaptadores para su funcionamiento. cuando se selecciona un item, la lista se contrae.

        ArrayAdapter<String> adapterSpinner = new ArrayAdapter<>(
                getApplicationContext(),
                android.R.layout.simple_spinner_item,
                listaMediosDePago
        );

        comboBox.setAdapter(adapterSpinner);

        /* ----------------------------FIN => BLOQUE DE CODIGO PARA EL SPINNER CON ARRAY DE STRINGS ----------------------------------------------------*/

        /* ----------------------------INICIO => BLOQUE DE CODIGO PARA EL SPINNER CON ARRAY DE OBJETOS ----------------------------------------------------*/


        Spinner comboBox2 = findViewById(R.id.spinnerMediosPago2); // Una lista tipo Spinner es un campo desplegable que despliega una lista de items (como un combo).
        // Los Spinner tambien necesitan adaptadores para su funcionamiento. cuando se selecciona un item, la lista se contrae.

        ArrayAdapter<Categorias> adapterSpinner2 = new ArrayAdapter<>(
                getApplicationContext(),
                android.R.layout.simple_spinner_item,
                //DataTemporal.CATEGORIAS
                DataTemporal.CATEGORIAS_INTERES     //toca primero usar la vista de RecyclerView para agregar las categorias de interes ya
                                    //al inicar la aplicación estara sin datos. y el spinner no mostrara ninguna opcion
        );

        comboBox2.setAdapter(adapterSpinner2);

        /* ----------------------------FIN => BLOQUE DE CODIGO PARA EL SPINNER CON ARRAY DE OBJETOS ----------------------------------------------------*/

    }

    /*------------------------------------------------------------------------------------*/
    public void enviarItemSelecSpinnerConArrayStrings(View ItemSelecSpinner){
        //Con esta funsión, capturamos el item seleccionado de el spinner y hacemos la accion deseada que para este ejemplo es un
        //Toast. Para que esta funcionalidad funcione bien, debe haberse implementado una interfaz de tipo simple_spinner_item, que fue
        // cuando usamos android.R.layout.simple_spinner_item.

        Spinner comboBox = findViewById(R.id.spinnerMediosPago);
        String elemento = (String) comboBox.getSelectedItem();
        Log.i("El elemento del spinner seleccionado fue: ", elemento);
        Toast.makeText(getApplicationContext(), "El elemento del spinner seleccionado fue: " + elemento, Toast.LENGTH_LONG).show();

    }
    /*-------------------------------------------------------------------------------------*/

    public void enviarItemSelecSpinnerConArrayObjetos(View ItemSelecSpinner){
        //Con esta funsión, capturamos el item seleccionado de el spinner y hacemos la accion deseada que para este ejemplo es un
        //Toast. Para que esta funcionalidad funcione bien, debe haberse implementado una interfaz de tipo simple_spinner_item, que fue
        // cuando usamos android.R.layout.simple_spinner_item.

        Spinner comboBox = findViewById(R.id.spinnerMediosPago2);
        Categorias elemento = (Categorias) comboBox.getSelectedItem();
        Log.i("El elemento del spinner seleccionado fue: ", elemento.toString());
        Toast.makeText(getApplicationContext(), "El elemento del spinner seleccionado fue: " + elemento, Toast.LENGTH_LONG).show();


        /*
        ListView listaProducts = findViewById(R.id.listaProductos3);
        Categorias valor = (Categorias) listaProducts.getItemAtPosition(listaProducts.getCheckedItemPosition()); // getItemAtPosition()
        // retorna un objeto en la posicion que se le indique y como es un objeto, entonces es necesario hacer un casteo
        // a el tipo de objeto Categorias ya que estamos trabajando con ellos y no con Strings. POr otro lado, el metodo getCheckedItemPosition() nos sirve para indicarle al
        //metodo getItemAtPosition le posicion del item seleccionado.

        Toast.makeText(getApplicationContext(), "==> El item Seleccionado tiene el  id: " + valor.getId()
                + ", Nombre: " + valor.getNombre() + " y Descripción: " + valor.getDescripcion()
                + " ------ Consolidado toString: " + valor.toString(), Toast.LENGTH_LONG).show();

         */
    }
    /*-------------------------------------------------------------------------------------*/
}