package co.com.personal.hnino.ejerciciosenclase;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

import co.com.personal.hnino.ejerciciosenclase.entidades.Categorias;

public class ListasEjemplosActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listas_ejemplos);

        /* ---------------------------- INICIO => BLOQUE DE CODICO PARA LISTA BASICA CON SU ESCUCHA CORRESPONDIENTE -----------------------------------*/
        ArrayAdapter<Categorias> adapter2 = new ArrayAdapter<>(getApplicationContext(),
                android.R.layout.simple_list_item_1, // recurso de android predefinido de tipo layout (es layout por qu vamos a mostrar elementos)
                // hay varias interfaces de listas predefinidas por android como
                //simple_list_item_1 que es la lista basica,  o como simple_list_item_multiple_choice (es con check boxs),
                // o como simple_list_item_single_choice (es con radio buttom)
                // o como simple_list_item_checked (es con chulos)
                DataTemporal.CATEGORIAS); // datos a mostrar en en la listView

        final ListView listaProducts = findViewById(R.id.listaProductos2); // Se declara como tipo final para que en el metodo anonimo
        //existente dentro de listaProducts.setOnItemClickListener se pueda accedr a esta variable

        listaProducts.setAdapter(adapter2);

        /* --------------- Escucha de evento cuando se hace click en uno de los items de la lista -----------------*/
        listaProducts.setOnItemClickListener(new AdapterView.OnItemClickListener() {  //setOnItemClickListener() es un metodo
            // de android que permite detectar cuando se hace un evento click en un item de la lista y se realiza la acción deseada.
            @Override
            public void onItemClick(  // onItemClick recibe 4 argumentos
                                      AdapterView<?> parent,    // Argumento 1 => el adaptador que contiene la lista de itemos
                                      View view, // Argumento 2 => El view ue se refiere al item que fue seleccionado
                                      int position, // Argumento 3 => numero entereo que representa la posición del array en el cual se hizo click.
                                      long id)  // Argumento 4 => id del elemento asiciado a ese item
            {
                Categorias valor = (Categorias) listaProducts.getItemAtPosition(position);  // Si la variable listaProducts no fuera
                //de tipo "final, entonces no se podría acceder por que estamos dentro de un metodo anonimo.
                Toast.makeText(getApplicationContext(), "==>Acción Click en Item con id: " + valor.getId()
                        + ", Nombre: " + valor.getNombre() + " y Descripción: " + valor.getDescripcion()
                        + " ------ Consolidado toString: " + valor.toString(), Toast.LENGTH_SHORT).show();
            }
        });

        /* ---------------------------- FIN => BLOQUE DE CODIGO PARA LISTA BASICA CON SU ESCUCHA CORRESPONDIENTE -----------------------------------*/

        /* ---------------------------- INICIO => BLOQUE DE CODIGO PARA LISTA SINGLE CHOISE (SELECCION DE UN SOLO ITEM DE LA LISTA) -----------------------------------*/
        ArrayAdapter<Categorias> adapter3 = new ArrayAdapter<>(getApplicationContext(),
                android.R.layout.simple_list_item_single_choice, // recurso de android predefinido de tipo layout (es layout por qu vamos a mostrar elementos)
                // hay varias interfaces de listas predefinidas por android como
                //simple_list_item_1 que es la lista basica,  o como simple_list_item_multiple_choice (es con check boxs),
                // o como simple_list_item_single_choice (es con radio buttom)
                // o como simple_list_item_checked (es con chulos)
                DataTemporal.CATEGORIAS); // datos a mostrar en en la listView

        final ListView listaProducts3 = findViewById(R.id.listaProductos3); // Se declara como tipo final para que en el metodo anonimo
        //existente dentro de listaProducts.setOnItemClickListener se pueda accedr a esta variable

        listaProducts3.setChoiceMode(ListView.CHOICE_MODE_SINGLE); //para poder seleccionar items de la lista configurada en la interfaz elegida,
        // en android.R.layout.XXXXXXXXXXXXXXXXXXXXX, debemos implementar el modo seleecion "setChoiceMode", y para lo anterior
        // ListView tiene varios modos de selección definidos por defecto, como por ejempli "CHOICE_MODE_MULTIPLE", o "CHOICE_MODE_SINGLE"
        // y varios mas

        listaProducts3.setAdapter(adapter3); //En pantalla se le motrara al usuario la lista de categorias con sus detalles, pero como las listas son predefinidas por Android se
                                    // Se presentan inconsistencias en la presentación de la información. como para este ejemplo que sale cortada por que se muestra mucha información.
                                // COmo se usa un layout predefinido, eso no puede ser corregido, la unica manera es umplementar un adaptador personalizado.

        /* ---------------------------- FIN => BLOQUE DE CODIGO PARA LISTA SINGLE CHOISE (SELECCION DE UN SOLO ITEM DE LA LISTA)  -----------------------------------*/

        /* ---------------------------- INICIO => BLOQUE DE CODIGO PARA LISTA MULTIPLE CHOISE (SELECCION DE VARIOS ITEM DE LA LISTA) -----------------------------------*/
        ArrayAdapter<Categorias> adapter4 = new ArrayAdapter<>(getApplicationContext(),
                android.R.layout.simple_list_item_multiple_choice, // recurso de android predefinido de tipo layout (es layout por que vamos a mostrar elementos)
                // hay varias interfaces de listas predefinidas por android como
                //simple_list_item_1 que es la lista basica,  o como simple_list_item_multiple_choice (es con check boxs),
                // o como simple_list_item_single_choice (es con radio buttom)
                // o como simple_list_item_checked (es con chulos)
                DataTemporal.CATEGORIAS); // datos a mostrar en en la listView

        final ListView listaProducts4 = findViewById(R.id.listaProductos4); // Se declara como tipo final para que en el metodo anonimo
        //existente dentro de listaProducts.setOnItemClickListener se pueda accedr a esta variable

        listaProducts4.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE); //para poder seleccionar items de la lista configurada en la interfaz elegida,
        // en android.R.layout.XXXXXXXXXXXXXXXXXXXXX, debemos implementar el modo seleecion "setChoiceMode", y para lo anterior
        // ListView tiene varios modos de selección definidos por defecto, como por ejemplo "CHOICE_MODE_MULTIPLE", o "CHOICE_MODE_SINGLE"
        // y varios mas

        listaProducts4.setAdapter(adapter4); //En pantalla se le motrara al usuario la lista de categorias con sus detalles, pero como las listas son predefinidas por Android se
        // Se presentan inconsistencias en la presentación de la información. como para este ejemplo que sale cortada por que se muestra mucha información.
        // COmo se usa un layout predefinido, eso no puede ser corregido, la unica manera es umplementar un adaptador personalizado.

        /* ---------------------------- FIN => BLOQUE DE CODIGO PARA LISTA MULTIPLE CHOISE (SELECCION DE VARIOS ITEM DE LA LISTA)  -----------------------------------*/

    }

    /*------------------------------------------------------------------------------------*/
    public void enviarItemSelec2(View ItemSelec){
        //Con esta funsión, capturamos el item seleccionado de la listView y hacemos la accion deseada que para este ejemplo es un
        //Toast. Para que esta funcionalidad funcione bien, debe haberse implementado una interfaz de tipo single_choice que fue
        // cuando usamos android.R.layout.simple_list_item_single_choice.

        ListView listaProducts = findViewById(R.id.listaProductos3);
        Categorias valor = (Categorias) listaProducts.getItemAtPosition(listaProducts.getCheckedItemPosition()); // getItemAtPosition()
        // retorna un objeto en la posicion que se le indique y como es un objeto, entonces es necesario hacer un casteo
        // a el tipo de objeto Categorias ya que estamos trabajando con ellos y no con Strings. POr otro lado, el metodo getCheckedItemPosition() nos sirve para indicarle al
        //metodo getItemAtPosition le posicion del item seleccionado.

        Toast.makeText(getApplicationContext(), "==> El item Seleccionado tiene el  id: " + valor.getId()
                + ", Nombre: " + valor.getNombre() + " y Descripción: " + valor.getDescripcion()
                + " ------ Consolidado toString: " + valor.toString(), Toast.LENGTH_LONG).show();
    }
    /*-------------------------------------------------------------------------------------*/
    public void enviarItemSelec3(View ItemsSeleccionados){ //En este caso hay varios items que fueron seleccionados
        //Con esta funsión, capturamos el uno o varios items seleccionados de la listView y hacemos la accion deseada que para este ejemplo es un
        //Toast. Para que esta funcionalidad funcione bien, debe haberse implementado una interfaz de tipo multiple_choice que fue
        // cuando usamos android.R.layout.simple_list_item_multiple_choice

        ListView listaProducts = findViewById(R.id.listaProductos4);

        String valoresString = "";

        SparseBooleanArray valores = listaProducts.getCheckedItemPositions();  //SparseBooleanArray es una conbinación de claves y valores donde las claves son como el id del
                                                            //de cada uno de los elementos seleccionados y el valor es un boleano true  o false de cada uno de los elementos
                                                    //seleccionados. El metodo getCheckedItemPositions() nos sirve para capturar cada una de las posiciones de los items
                                        // que fueron seleccionados de la lista.

       Log.i("===> Cantidad de elementos seleccionados: ", ""+valores.size()); // ""+valores.size() ==> las 2 comillas y el + se usan para que el sistema detecte que se desea
                                                                                        // mostrar el el valor de la variable correspondiente representada en cadena de texto.
        for (int i=0; i<valores.size(); i++){   //usamos un for para reccorrer el array correspondiente.
            if(valores.valueAt(i)){ // si valores en la posición i es verdadero, entonces es por que fue seleccionado y puede ser recuperado y si es false, entonces no fue seleccionado y no puede ser recuperado.
                Categorias valor = (Categorias) listaProducts.getItemAtPosition(valores.keyAt(i)); //Capturamos el item en la posición i. tener en cuenta que los items,
                                                                                    //se asocian a partir el tipo de adaptador que se este usando que para este caso el adaptador
                                                                        // usado fue configurado con el layout android.R.layout.simple_list_item_multiple_choice,
                valoresString += valor.getNombre() + "\n";
            }
        }

        Toast.makeText(getApplicationContext(), "==> Los item Seleccionados tienen los siguientes Nombres: \n" + valoresString, Toast.LENGTH_LONG).show();

    }

}