package co.com.personal.hnino.ejerciciosenclase;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import co.com.personal.hnino.ejerciciosenclase.entidades.Categorias;

public class AgregarCategoriaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar_categoria);
    }

    public void regresar(View view){
        setResult(RESULT_CANCELED);
        finish();
    }

    public void agregarCategoria(View view){

        EditText idCat = findViewById(R.id.numIdEnAgregarCategoria);
        EditText nombre = findViewById(R.id.txtNombreCatEnAgregarCategoria);
        EditText descripcion = findViewById(R.id.txtDescripcionEnAgregarCategoria);
        EditText urlImagen = findViewById(R.id.txtUrlImagenEnAgregarCategoria);

        int idCateg = Integer.parseInt(idCat.getText().toString());

        Categorias newCategoria = new Categorias(idCateg, nombre.getText().toString(), descripcion.getText().toString());
        newCategoria.setUrlImagen(urlImagen.getText().toString());
        DataTemporal.CATEGORIAS.add(newCategoria);

        setResult(RESULT_OK);
        finish();
    }
}