package co.com.personal.hnino.ejerciciosenclase;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

//vamos en video 4 de la semana 3 en 1 hora, 35 min y 50 seg.

// Pagina recomendada para consutar y ver ejemplos asociados a todos los temas de Android => https://www.vogella.com/tutorials/android.html

//para este proyecto de ejemplo, dentro de los recursos, se creo la carpeta xml y dentro de ella se creo el archivo
//network_security_config.xml en el cual se configuro el atributo cleartextTrafficPermitted="true" que es para habilitar
//restricciones de res que presentan algunas versiones de android para que se puedan ejecutar acciones de servicios locales.
//esta accion tambien lo configuramos en el archivo de manifiesto en la linea que agregamos android:networkSecurityConfig="@xml/network_security_config"


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i("======> OnCreate: ", "OK en MainActivity");
        setContentView(R.layout.activity_main);

        if (DataTemporal.CATEGORIAS.size() == 0){
            DataTemporal.cargarCategorias();
        }

        /*-----------------------------------------------------------------------------*/
        Button btnRegistrarsee = findViewById(R.id.btnRegistrarse);

        btnRegistrarsee.setOnLongClickListener(new View.OnLongClickListener() {   // new View.OnLongClickListener() es una clase anonima
            // debido a que no se puede refenciar a ese objeto ya que existe
            // solo dentro del botón, fuera del botón nadie lo conoce.
            @Override
            public boolean onLongClick(View view) {
                Toast.makeText(MainActivity.this, "Click Sostenido", Toast.LENGTH_SHORT).show(); // MainActivity.this toma
                // el contexto de la clase  MainActivity, pero por comodidad
                // se recomienda mejor usar el getApplicationContext() ya que de esta forma, si
                //tuvieramos que copiar este codigo y pegarlo en otros lados no necesitatiamos cambiar nada,
                // ya que getApplicationContext() entien en que contexto se encuenta. para este caso se dejo
                // MainActivity.this para tener un ejemplo. Si dejaramos solo "this" entonces se haria
                // referencia al objeto anonimo OnLongClickListener() y no a MainActivity.

                // En conclusión sienpre que necesitemos el contecto de la aplicación, lo mejor es usar getApplicationContext()
                return false;
            }
        });
        /*-------------------------------------------------------------------------------------------*/
        EditText numIdentificacion = findViewById(R.id.txtNumIdentificacion);
        numIdentificacion.setOnClickListener(eventoClick);   // Si se hace click se realiza lo definido en eventClick.

        EditText nombreCompleto = findViewById(R.id.txtNombreCompleto);
        nombreCompleto.setOnClickListener(eventoClick);  // Si se hace click se realiza lo definido en eventClick.

        EditText correoE = findViewById(R.id.txtCorreoE);
        correoE.setOnClickListener(eventoClick);  // Si se hace click se realiza lo definido en eventClick.

        Button btnSalir = findViewById(R.id.btnSalir);
        btnSalir.setOnClickListener(eventoClick);  // Si se hace click se realiza lo definido en eventClick.

    }

    View.OnClickListener eventoClick = new View.OnClickListener() {

        @Override
        public void onClick(View view) {
            if (view.getId() == R.id.txtNumIdentificacion){
                Toast.makeText(getApplicationContext(), "Ingrese su numero de identificación ", Toast.LENGTH_LONG).show();
            }
            else if (view.getId() == R.id.txtNombreCompleto){
                Toast.makeText(getApplicationContext(), "Ingrese su nombre completo ", Toast.LENGTH_LONG).show();
            }
            else if(view.getId() == R.id.txtCorreoE){
                Toast.makeText(getApplicationContext(), "Ingrese su correo electronico ", Toast.LENGTH_LONG).show();
            }
            else if(view.getId() == R.id.btnSalir){
                Toast.makeText(getApplicationContext(), "Has Salido... Ough ", Toast.LENGTH_LONG).show();
                MainActivity.super.finish();
            }

        }
    };

    /*
        // Podemos blouqear la manera de salir de la aplicación de forma normal cuando se usa el botón de back.
        // inhabilidar el back (retornar a pantalla anterior) implica la necesidad de sobreescribir el metodo finish
        @Override
        public void finish() {
            //super.finish(); // Al dejar esta parte como comentario, le estamos diciendo al metodo Finish que es el mismo back que
            //no haga nada.
        }
    */
    /*--------------------------------------------------------------------------------------------------------------*/
    public void iniciarSesion(View registro){

        EditText numIdentificacion = findViewById(R.id.txtNumIdentificacion); // No se necesita hacer casteo por que ya reconoce el tipo de dato del campo de origen, es decur si es numerico, un texto etc
        //Tener en cuenta que los elementos de las Vistas como los campos de texto o númericos son de tipo EditText
        EditText nombreCompleto = findViewById(R.id.txtNombreCompleto); //R.   Clase para trabajar y llamar los recursos
        EditText correoE = findViewById(R.id.txtCorreoE);

        String numIdentificacionString = numIdentificacion.getText().toString(); //el tipo EditText es un formato de tipo Editable que nos entrega el metodo getText(), y para pasarlo a formato String (cadena de texto), se debe usar el metodo toString que es la cadena de texto
        String nombreCompletoString = nombreCompleto.getText().toString();
        String correoEString = correoE.getText().toString();

        Log.i("Validar Identificacion", numIdentificacionString); // La clase Log permite ver Logs en la pestaña Logcat, i para log de informacion, d para log
        // de debug y e para un log de error. las variables deben ser cadenas, por eso es que usamos
        // la variable nombreCompletoString para este ejemplo como tambien podríamos poner textos entre ""
        Log.d("Valor Nombre Completo", nombreCompletoString);
        Log.i("Valor Correo Electronico", correoEString);

        if (numIdentificacionString.equalsIgnoreCase("12345") && nombreCompletoString.equalsIgnoreCase("hnino")){
            //Toast.makeText(getApplicationContext(), "Bienvenid@", Toast.LENGTH_SHORT).show();
            Toast.makeText(getApplicationContext(), "Bienvenid@ " + nombreCompleto.getText(), Toast.LENGTH_LONG).show(); // Notificación tipo burbuja para mensajes
            // informativos que desaparecen despues de x tiempo
            // tenendo en cuenta lo configurado en LENGTH_XXXXX  donde XXXXX
            // puede ser SHORT o LONG
            //En cuanto al contexto, se recomienda usar getApplicationContext() para evitar confuciones con el uso de this y su contexto
            Intent intentActivityMenuPrincipal = new Intent(MainActivity.this, MenuPrincipalActivity.class);    // Los Intent son objetos de mensajeria para solicitar una acción de otro
            // componente de una app. se usa para iniciar otra actividad, vista o pantalla
            // como se le quiera llamar. el primer parametro "MainActivity.this" es el contexto actual
            //y el segundo parametro es el contexto destino.

            // Cada ves que se usa a un intent, la pantalla anterior va quedando en una pila, a la cual
            // se puede retornar a esa pantalla usando el boton back. Si hay 5 Intent, esas 5 pantallas
            // quedan en la pila.
            intentActivityMenuPrincipal.putExtra("numIdentificacionStr", numIdentificacionString);  //el metodo putExtra, nos ayudapara enviar información complementaria hacia la otra actividad para que pueda ser usada alli
            intentActivityMenuPrincipal.putExtra("nombreCompletoStr", nombreCompletoString);

            //startActivity(intentActivityMenuPrincipal); // inicia actividad con los parametros del intent intentActivityMenuPrincipal. startActivity hace la invocación sin esperar resultado

            startActivityForResult(intentActivityMenuPrincipal, 200);   // inicia actividad con los parametros del intent intentActivityMenuPrincipal, El segundo parametro
            // es un codigo de petición el cual es un valor entero, para este ejemplo le pusimos el codigo 200 .
            // El metodo startActivityForResult (lanzar y esperar respuesta) hace la invocación,
            // y espera una respuesta y/o resultado. El metodo startActivityForResult funciona, pero no se recomienda usar ya que es un metodo deprecado,
            //es decir que en proximas versiones de Android ya no va a existir.

            //finish();       // despues de iniciarse la actividad descrita en la linea anterior, Se finaliza esta actividad
            // para que no quede en cola.



        }
        else{
            numIdentificacion.setText(null);
            nombreCompleto.setText(null);
            correoE.setText(null);
        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) { // Se recibe la respuesta de
        // "setResult(RESULT_OK, intentBtnEviar);" existente en la actividad ActivityMenuPrincipal. El argumento requestCode es el argumento que decribe quien genero la petición,
        // para este ejercicio, seria el codigo 200, que fue el usado en la linea ---- startActivityForResult(intentActivityMenuPrincipal, 200); ----
        // resultCode es el argumento que describe el resultado, es decir si se pudo hacer bien o no, y argumento data  que podria ser @Nullable, es decir que ese
        //argumento podría no ser enviado.
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode==200){
            if (resultCode==RESULT_OK){
                String msg = "La edad del usuario es: ";
                if(data != null){
                    int edad = data.getIntExtra("edad", -1); // Si Intent data no es enviado, entonces el valor
                    // de edad es -1 por defecto
                    if (edad == -1){
                        msg += "N/D - No Disponible";
                    }
                    else{
                        msg += edad;
                    }
                }
                Toast.makeText(getApplicationContext(), "Resultado:  Ok " + msg, Toast.LENGTH_SHORT).show();
            }
            else {
                Log.e("=====> Error: ", "Algo pasoo");
            }
        }

    }
    /*-----------------------------------------------------------------------------------------------------------*/
    public void iniciarSesion2(View registro){

        EditText numIdentificacion = findViewById(R.id.txtNumIdentificacion); // No se necesita hacer casteo por que ya reconoce el tipo de dato del campo de origen, es decur si es numerico, un texto etc
        //Tener en cuenta que los elementos de las Vistas como los campos de texto o númericos son de tipo EditText
        EditText nombreCompleto = findViewById(R.id.txtNombreCompleto); //R.   Clase para trabajar y llamar los recursos
        EditText correoE = findViewById(R.id.txtCorreoE);

        String numIdentificacionString = numIdentificacion.getText().toString(); //el tipo EditText es un formato de tipo Editable que nos entrega el metodo getText(), y para pasarlo a formato String (cadena de texto), se debe usar el metodo toString que es la cadena de texto
        String nombreCompletoString = nombreCompleto.getText().toString();
        String correoEString = correoE.getText().toString();

        Log.i("Validar Identificacion", numIdentificacionString); // La clase Log permite ver Logs en la pestaña Logcat, i para log de informacion, d para log
        // de debug y e para un log de error. las variables deben ser cadenas, por eso es que usamos
        // la variable nombreCompletoString para este ejemplo como tambien podríamos poner textos entre ""
        Log.d("Valor Nombre Completo", nombreCompletoString);
        Log.i("Valor Correo Electronico", correoEString);

        if (numIdentificacionString.equalsIgnoreCase("12345") && nombreCompletoString.equalsIgnoreCase("hnino")){
            //Toast.makeText(getApplicationContext(), "Bienvenid@", Toast.LENGTH_SHORT).show();
            Toast.makeText(getApplicationContext(), "Bienvenid@ => " + nombreCompleto.getText(), Toast.LENGTH_LONG).show(); // Notificación tipo burbuja para mensajes
            // informativos que desaparecen despues de x tiempo
            // tenendo en cuenta lo configurado en LENGTH_XXXXX  donde XXXXX
            // puede ser SHORT o LONG
            //En cuanto al contexto, se recomienda usar getApplicationContext() para evitar confuciones con el uso de this y su contexto
            Intent intentActivityMenuPrincipal = new Intent(MainActivity.this, MenuPrincipalActivity.class);    // Los Intent son objetos de mensajeria para solicitar una acción de otro
            // componente de una app. se usa para iniciar otra actividad, vista o pantalla
            // como se le quiera llamar. el primer parametro "MainActivity.this" es el contexto actual
            //y el segundo parametro es el contexto destino.

            // Cada ves que se usa a un intent, la pantalla anterior va quedando en una pila, a la cual
            // se puede retornar a esa pantalla usando el boton back. Si hay 5 Intent, esas 5 pantallas
            // quedan en la pila.
            intentActivityMenuPrincipal.putExtra("numIdentificacionStr", numIdentificacionString);  //el metodo putExtra, nos ayudapara enviar información complementaria hacia la otra actividad para que pueda ser usada alli
            intentActivityMenuPrincipal.putExtra("nombreCompletoStr", nombreCompletoString);

            btnIniciarSesion2.launch(intentActivityMenuPrincipal);

            //finish();       // despues de iniciarse la actividad descrita en la linea anterior, Se finaliza esta actividad
            // para que no quede en cola.

        }

        else{
            numIdentificacion.setText(null);
            nombreCompleto.setText(null);
            correoE.setText(null);
        }

    }

    ActivityResultLauncher<Intent> btnIniciarSesion2 = registerForActivityResult( //EL primer argumento de
            // registerForActivityResult es un
            // ActivityResultContract, el cual viene siendo una instancia
            // de  startActivityForResult y el segundo argumento es un ActivityResultRegistry
            // ó un ActivityResultCallback, Para este ejemplo, usamos un ActivityResultCallback que es el metodo definido
            // que se va a generar cuando el resultado regrese, que a la final, se resulta usando el mismo onActivityResult
            // usdado con startActivityForResult pero ya no se trabaja con el requestCode debido a que ya no se llama a un
            // metodo general sino que se llama a un metodo puntual que es el caso cuando usamos
            // btnIniciarSesion2.launch(intentActivityMenuPrincipal); que lanza al intent correspondiente y en este caso ya se
            // puede controlar el intent que se esta mandando y como ya se sabe cual es el intent que se esta mandando, entonces
            // en el callback ya no se necesita saber de donde viene, ya que el resultado regresa solamente a quien lo llamo
            // que para este ejemplo es btnIniciarSesion2


            new ActivityResultContracts.StartActivityForResult(),   // ActivityResultContract como primer argumento
            new ActivityResultCallback<ActivityResult>() {          // ActivityResultCallback como segundo argumento
                @Override
                public void onActivityResult(ActivityResult resultado) {   // Este metodo ya no es de la clase MainActivity
                    // sino que va a ser del objeto anonimo
                    if(resultado.getResultCode() == RESULT_OK){
                        String msg = "La edad del usuario es: ";
                        Intent intent = resultado.getData();
                        if(intent != null){
                            int edad = intent.getIntExtra("edad", -1); // Si Intent data no es enviado, entonces el valor
                            // de edad es -1 por defecto
                            if (edad == -1){
                                msg += "N/D - No Disponible";
                            }
                            else{
                                msg += edad;
                            }
                        }
                        Toast.makeText(getApplicationContext(), "btnIniciarSesion2 => Resultado:  Ok " + msg, Toast.LENGTH_LONG).show();
                    }
                    else {
                        Log.e("=====> Error: ", "Algo pasoo");
                    }
                }
            }
    );


    /*--------------------------------------------------------------------------------------------------*/

    @Override
    protected void onStart() {
        super.onStart();
        Log.i("======> OnStart: ", "OK en MainActivity");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.i("======> OnResume: ", "OK en MainActivity");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.i("======> OnPause: ", "OK en MainActivity");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.i("======> OnStop: ", "OK en MainActivity");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.i("======> OnRestart: ", "OK en MainActivity");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i("======> OnDestroy: ", "OK en MainActivity");
    }

}