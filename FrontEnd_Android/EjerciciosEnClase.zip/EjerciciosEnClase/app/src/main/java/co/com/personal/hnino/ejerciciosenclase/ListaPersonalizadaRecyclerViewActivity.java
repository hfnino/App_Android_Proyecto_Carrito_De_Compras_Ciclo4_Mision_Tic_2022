package co.com.personal.hnino.ejerciciosenclase;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.View;

import co.com.personal.hnino.ejerciciosenclase.entidades.Categorias;

public class ListaPersonalizadaRecyclerViewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycler_view);

        RecyclerView listaRecycler = findViewById(R.id.listaRecycler); //El RecyclerView es un witget de android, es una vista de grupo (ViewGroup) ya que
        // es un contenedor que nos permite mostrar un listado (ListView) o una grilla (gridView) de elementos. El RecyclerView es una versión mejorada de la
        // clase ListView y lleva este nombre porque a medida que se renderizan los elementos de la lista, los elementos que dejan de observarse se reciclan
        // o se reutilizan para mostrar los elementos siguientes mejorando los tiempos de carga y respuesta ya que se cargan en memoria solo los elementos
        // visibles en ese momento, mientas que el ListView carga todos los elementos.

        //Para implementar el RecyclerView debemos agregar la librería de RecyclerView en el gradle:

        //implementation 'androidx.recyclerview:recyclerview:1.2.1'

        LinearLayoutManager linearLayout = new LinearLayoutManager(getApplicationContext()); // el RecyclerView maneja por defecto un layout tipo LinearLayout

        listaRecycler.setLayoutManager(linearLayout); // linearLayout que es de la clase linearLayoutManager es el que nos va a manejar el contenido
                                            //de nuestro RecyclerView
        /*
        // EL RecyclerView siempre va a necesitar un adaptador ya que no cuenta con adaptadores predefinidos como si los hay para las ListView como es el caso del ArrayAdapter,
        por esto es que el adaptador creado a continuación no nos sirve.
        ArrayAdapter<Categorias> adapterRecyclerView = new ArrayAdapter<>(
                getApplicationContext(),
                android.R.layout.simple_list_item_1,
                DataTemporal.CATEGORIAS
        );

        listaRecycler.setAdapter(adapterRecyclerView);
        */

        CategoriaAdapterRecycler adapterRecyclerView = new CategoriaAdapterRecycler(
                DataTemporal.CATEGORIAS,
                new CategoriaAdapterRecycler.OnItemClickListenerRecyclerView() { // el metos .OnItemClickListenerRecyclerView() es
                                                                // la interface quecreamos en la clase CategoriaAdapterRecycler
                    @Override
                    public void onItemClickRecyclerView(Categorias categoria) {
                        Log.i("====> Categoria seleccionada => ", categoria.getNombre());
                        DataTemporal.CATEGORIAS_INTERES.add(categoria);

                    }
                }
        );

        listaRecycler.setAdapter(adapterRecyclerView);

        // En el ReciclerView al ser un componente externo, no cuenta un metodo de escucha para los eventos click como es el caso del OnItemViewListener en los ListView
        // por tanto se hace oblicatorio que en la creacion del adaptador personalozado usado por el ReciclerView, se implemente un metodo que realice la escucha de los
        //eventos click que para este prollecto lo creamos dentro del codico de la clase CategoriaAdapterRecycler

        listaRecycler.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.i("======> View = ", "" + view.toString());
            }
        });

    }
}