package co.com.personal.hnino.ejerciciosenclase;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class MenuPrincipalActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i("======> OnCreate: ", "OK en ActivityMenuPrincipal");
        setContentView(R.layout.activity_menu_principal);

        String nombreCompletoString = getIntent().getStringExtra("nombreCompletoStr");
        String numIdentificacionString = getIntent().getStringExtra("numIdentificacionStr");

        TextView nombreCompletoStringTextView = findViewById(R.id.lbNombreCompleto);
        TextView numIdentificacionTextView = findViewById(R.id.lbIdentif);

        nombreCompletoStringTextView.setText("Datos de Perfil ==> Nombre Completo: " + nombreCompletoString);
        numIdentificacionTextView.setText("Datos de Perfil ==> No. de Identificación: " + numIdentificacionString);

        TextView numCelular = findViewById(R.id.numMovil);
        numCelular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //EditText numCel = (EditText) view; // Hacemos un casteo para convertir el elemento  view en etiqueta EditText
                Intent intentllamadaTel = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:3001234567" ));
                // Intent.ACTION_DIAL es la acción que se va a realizar, y a travez de la clase Uri se envia la variable
                //numCel que es la view de tipo EditText que tiene el numero telefonico celular al que se va a llamar.
                startActivity(intentllamadaTel);

            }
        });   // Si se hace click se realiza lo definido en eventClick.

        /*-------------------------------------------------------------*/
        Button volverIntent = findViewById(R.id.btnVolverIntent);

        volverIntent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MenuPrincipalActivity.this, MainActivity.class);
                startActivity(intent);     // Acomula esta pantalla en la pila
            }
        });
        /*--------------------------------------------------------------*/
        Button volverFinish = findViewById(R.id.volverFinish);

        volverFinish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setResult(RESULT_CANCELED); //respuesta al startActivityForResult de la activiada MainActivity
                finish();  //Finaliza la actividad actual y se visualiza la pantalla mas reciente existente en la pila.
            }
        });
        /*----------------------------------------------------------------*/

        String[] listaProductoss = {"Aseo Personal", "Aseo Hogar", "Alimentos", "Bebidas", "Electrodomesticos",
                "Lacteos", "Cereales", "Licores", "Carnes", "Abarrotes", "Frutas", "Verduras" };

        ArrayAdapter<String> adapter = new ArrayAdapter<>(getApplicationContext(),
                android.R.layout.simple_list_item_single_choice, // recurso de android predefinido de tipo layout (es layout por qu vamos a mostrar elementos)
                                                    // hay varias interfaces de listas predefinidas por android como
                                                //simple_list_item_1  o como simple_list_item_multiple_choice (es con check boxs),
                                            // o como simple_list_item_single_choice (es con radio buttom)
                                            // o como simple_list_item_checked (es con chulos)
                listaProductoss); // datos a mostrar en en la listView

        final ListView listaProducts = findViewById(R.id.listaProductos); // Se declara como tipo final para que en el metodo anonimo
                                            //existente dentro de listaProducts.setOnItemClickListener se pueda accedr a esta variable

        listaProducts.setChoiceMode(ListView.CHOICE_MODE_SINGLE); //para poder seleccionar items de la lista configurada en la interfaz elegida,
        // en android.R.layout.XXXXXXXXXXXXXXXXXXXXX, debemos implementar el modo seleecion "setChoiceMode", y para lo anterior
        // ListView tiene varios modos de selección definidos por defecto, como por ejempli "CHOICE_MODE_MULTIPLE", o "CHOICE_MODE_SINGLE"
        // y varios mas

        listaProducts.setAdapter(adapter);

        /* --------------- Escucha de evento cuando se hace click en uno de los items de la lista -----------------*/
        listaProducts.setOnItemClickListener(new AdapterView.OnItemClickListener() {  //setOnItemClickListener() es un metodo
            // de android que permite detectar cuando se hace un evento click en un item de la lista y se realiza la acción deseada.
            @Override
            public void onItemClick(  // onItemClick recibe 4 argumentos
                    AdapterView<?> parent,    // Argumento 1 => el adaptador que contiene la lista de itemos
                    View view, // Argumento 2 => El view ue se refiere al item que fue seleccionado
                    int position, // Argumento 3 => numero entereo que representa la posición del array en el cual se hizo click.
                    long id)  // Argumento 4 => id del elemento asiciado a ese item
                    {
                        String valor = (String) listaProducts.getItemAtPosition(position);  // Si la variable listaProducts no fuera
                                               //de tipo "final, entonces no se podría acceder por que estamos dentro de un metodo anonimo.
                        Toast.makeText(getApplicationContext(), "==>Acción Click en: " + valor, Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void enviar(View view){
        EditText txtEdad = findViewById(R.id.txtEdad);
        int intEdad = -1;

        if (txtEdad.getText().toString().length()>0){
            intEdad = Integer.parseInt(txtEdad.getText().toString());
        }

        Intent intentBtnEviar = new Intent(); // Este Intent lo creamos sin ningun proposito, solo para que a continuación podamos
        // usar el putExtra
        intentBtnEviar.putExtra("edad", intEdad);
        setResult(RESULT_OK, intentBtnEviar); //respuesta que recibe el onActivityResult del startActivityForResult ó el
        // onActivityResult del btnIniciarSesion2 de la actividad MainActivity
        finish();
    }
    /*------------------------------------------------------------------------------------*/
    public void enviarItemSelec(View ItemSelec){
        //Con esta funsión, capturamos el item seleccionado de la listView y hacemos la accion deseada que para este ejemplo es un
        //Toast. Para que esta funcionalidad funcione bien, debe haberse implementado una interfaz de tipo single_choice que fue
        // cuando usamos android.R.layout.simple_list_item_single_choice.

        ListView listaProducts = findViewById(R.id.listaProductos);
        String valor = (String)listaProducts.getItemAtPosition(listaProducts.getCheckedItemPosition()); // getItemAtPosition()
                // retorna un objeto en la posicion que se le indique y como es un ojeto,entonces es necesario hacer un casteo
                // a String para tener el valor. POr otro lado, el metodo getCheckedItemPosition() nos sirve para indicarle al
                //metodo getItemAtPosition le posicion del item seleccionado.


       // String valor = (String) listaProducts.getSelectedItem(); // getSelectedItem() retorna un objeto, por eso es necesario hacer un
                            //casteo a String para tener el valor. Ademas del getSelectedItem(), tambien hay otros metodos utiles como
                            //getSelectedItemId() que retorna el id del item seleccionado  o el getSelectedItemPosition() que retorna
                            //el indice de la posicion del item seleccionado asociado al array correspondiente.
        Toast.makeText(getApplicationContext(), "==> El item Seleccionado es:  " + valor, Toast.LENGTH_SHORT).show();
    }
    /*-------------------------------------------------------------------------------------*/
    public void VerActivityListasEjemplos(View VerActivityListasEjemplo){
        Intent intentListasEjemplosActivity = new Intent(getApplicationContext(), ListasEjemplosActivity.class);
        startActivity(intentListasEjemplosActivity);
    }
    /*------------------------------------------------------------------------------------*/

    public void VerActivitySpinnersEjemplos(View VerActivitySpinnersEjemplos){
        Intent intentSpinnrsEjemplosActivity = new Intent(getApplicationContext(), SpinnersEjemplosActivity.class);
        startActivity(intentSpinnrsEjemplosActivity);
    }
    /*------------------------------------------------------------------------------------*/

    public void VerListaPersonalizadaUnoActivity(View VerListaPersonalizadaActivity){
        Intent intentListaPersonalizadaUnoActivity = new Intent(getApplicationContext(), ListaPersonalizadaActivity.class);
        startActivity(intentListaPersonalizadaUnoActivity);
    }
    /*------------------------------------------------------------------------------------*/

    public void VerListaPersonalizadaPicassoActivity(View VerListaPersonalizadaActivity){
        Intent intentListaPersonalizadaUnoActivity = new Intent(getApplicationContext(), ListaPersonalizadaPicassoActivity.class);
        startActivity(intentListaPersonalizadaUnoActivity);
    }
    /*------------------------------------------------------------------------------------*/

    public void VerListaPersonalizadaRecyclerViewActivity(View VerListaPersonalizadaRecyclerViewActivity){
        Intent intentListaPersonalizadaRecyclerViewActivity = new Intent(getApplicationContext(), ListaPersonalizadaRecyclerViewActivity.class);
        startActivity(intentListaPersonalizadaRecyclerViewActivity);
    }
    /*------------------------------------------------------------------------------------*/

    public void VerListaPersonalizadaRecyclerViewActivity2(View VerListaPersonalizadaRecyclerViewActivity2){
        Intent intentListaPersonalizadaRecyclerViewActivity2 = new Intent(getApplicationContext(), ListaPersonalizadaRecyclerViewActivity2.class);
        startActivity(intentListaPersonalizadaRecyclerViewActivity2);
    }
    /*------------------------------------------------------------------------------------*/
    public void verAgregarCategoria(View verAgregarCategoria){
        Intent intentAgregarAtegoriaActivity = new Intent(getApplicationContext(), AgregarCategoriaActivity.class);
        btnLanzarViewAgregarCategoria.launch(intentAgregarAtegoriaActivity);
    }

    ActivityResultLauncher<Intent> btnLanzarViewAgregarCategoria = registerForActivityResult( //EL primer argumento de
            // registerForActivityResult es un
            // ActivityResultContract, el cual viene siendo una instancia
            // de  startActivityForResult y el segundo argumento es un ActivityResultRegistry
            // ó un ActivityResultCallback, Para este ejemplo, usamos un ActivityResultCallback que es el metodo definido
            // que se va a generar cuando el resultado regrese, que a la final, se resulta usando el mismo onActivityResult
            // usdado con startActivityForResult pero ya no se trabaja con el requestCode debido a que ya no se llama a un
            // metodo general sino que se llama a un metodo puntual que es el caso cuando usamos
            // btnIniciarSesion2.launch(intentActivityMenuPrincipal); que lanza al intent correspondiente y en este caso ya se
            // puede controlar el intent que se esta mandando y como ya se sabe cual es el intent que se esta mandando, entonces
            // en el callback ya no se necesita saber de donde viene, ya que el resultado regresa solamente a quien lo llamo
            // que para este ejemplo es btnIniciarSesion2


            new ActivityResultContracts.StartActivityForResult(),   // ActivityResultContract como primer argumento
            new ActivityResultCallback<ActivityResult>() {          // ActivityResultCallback como segundo argumento
                @Override
                public void onActivityResult(ActivityResult resultado) {   // Este metodo ya no es de la clase MainActivity
                    // sino que va a ser del objeto anonimo
                    if(resultado.getResultCode() == RESULT_CANCELED){

                        Toast.makeText(getApplicationContext(), "Has regresado al menú principal ", Toast.LENGTH_LONG).show();
                    }
                    else if(resultado.getResultCode() == RESULT_OK){
                        Toast.makeText(getApplicationContext(), "La Categoria se agrego correctamente ---- Has regresado al menú principal ", Toast.LENGTH_LONG).show();

                    }
                    else {
                        Log.e("=====> Error: ", "Algo pasoo");
                        Toast.makeText(getApplicationContext(), "Error:   Algo paso", Toast.LENGTH_LONG).show();
                    }
                }
            }
    );
    /*------------------------------------------------------------------------------------*/

    @Override
    protected void onStart() {
        super.onStart();
        Log.i("======> OnStart: ", "OK en ActivityMenuPrincipal");

    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.i("======> OnResume: ", "OK en ActivityMenuPrincipal");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.i("======> OnPause: ", "OK en ActivityMenuPrincipal");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.i("======> OnStop: ", "OK en ActivityMenuPrincipal");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.i("======> OnRestart: ", "OK en ActivityMenuPrincipal");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i("======> OnDestroy: ", "OK en ActivityMenuPrincipal");
    }

}