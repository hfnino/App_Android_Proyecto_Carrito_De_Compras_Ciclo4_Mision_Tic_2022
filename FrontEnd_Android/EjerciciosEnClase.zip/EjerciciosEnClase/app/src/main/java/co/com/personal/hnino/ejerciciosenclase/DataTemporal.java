package co.com.personal.hnino.ejerciciosenclase;

import java.util.ArrayList;


import co.com.personal.hnino.ejerciciosenclase.entidades.Categorias;

public class DataTemporal {

    public  static  final ArrayList<Categorias> CATEGORIAS = new ArrayList<>();
    public  static  final ArrayList<Categorias> CATEGORIAS_INTERES = new ArrayList<>();

    static void cargarCategorias(){
        CATEGORIAS.add(new Categorias(1,"Aseo Personal", "Elementos de aseo para el cuidado personal"));
        CATEGORIAS.add(new Categorias(2,"Aseo Hogar", "Elementos de aseo para limpieza del hogar"));
        CATEGORIAS.add(new Categorias(3,"Alimentos", "Gran variedad de productos comestibles"));
        CATEGORIAS.add(new Categorias(4,"Bebidas", "Productos refrescantes para cualquier ocación"));
        CATEGORIAS.add(new Categorias(5,"Electrodomesticos", "Dispositivos electronicos para Entretenimiento"));
        CATEGORIAS.add(new Categorias(6,"Lacteos", "Variedad de productos derivados de la leche"));
        CATEGORIAS.add(new Categorias(7,"Cereales", "Productos Cereales en general"));
        CATEGORIAS.add(new Categorias(8,"Licores", "Todo tipo de Licores"));
        CATEGORIAS.add(new Categorias(9,"Carnes", "Lasr carnes mas finas de todo tipo"));

    }

}
