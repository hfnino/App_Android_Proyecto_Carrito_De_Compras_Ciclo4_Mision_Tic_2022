package co.com.personal.hnino.ejerciciosenclase;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import co.com.personal.hnino.ejerciciosenclase.entidades.Categorias;

public class CategoriaAdapterRecycler
        extends RecyclerView.Adapter<CategoriaAdapterRecycler.CategoriaViewHolder> {  // las clases que se creen para un adaptador personalizado de un RecyclerView,
                                        // siempre deben heredar y/o extender de RecyclerView.Adapter y a este ultimo se le debe indicar el ViewHolder correspondiente
                                        // que es el que definimos en uno de los metodos siguientes que llamamos CategoriaViewHolder. En estos casos ya no se debe heredar
                                    // de BaseAdapter como en los listView. ----- La clase RecyclerView.Adapter que es de la que heredamos, tiene metodos abstractos
                                   // que debemos implementar como es el caso del onCreateViewHolder, el onBindViewHolder y el getItemCount y tambien los implementamos
                                // a continuación.

    ArrayList<Categorias> categorias;
    OnItemClickListenerRecyclerView listenerRecyclerView; // Creamos atributo de tipo OnItemClickListenerRecyclerView necesario
                                                    //para poder implementar el escucha de lso eventos click para el RecyclerView

    public CategoriaAdapterRecycler(ArrayList<Categorias> categorias) {     // Creamos constructor asociado al atributo categorias de clase ArrayList<Categorias>
        this.categorias = categorias;
    }

    public CategoriaAdapterRecycler(ArrayList<Categorias> categorias, OnItemClickListenerRecyclerView listenerRecyclerView) {     // Creamos otro constructor (sobrecarga) asociado a los 2 atributos de esta clase
        this.categorias = categorias;
        this.listenerRecyclerView = listenerRecyclerView;
    }
    static  class  CategoriaViewHolder extends RecyclerView.ViewHolder{ // Esta es una clase interna , es decir una clase contenida dento de otra clase y ademas
                                                                        //  es estatica  por lo que no necesitamos instanciarla .
                                                                        // Este es el ViewHolder que lo llamamos CategoriaViewHolder o como queramos.
                                                                    // Este metodo debe extender del RecyclerView.ViewHolder ---- EL ViewHolder es el encargado
                                                                    // de gestionar y/o vincular los componentes visuales de cada vista con
                                                                    // los datos dinamicos que queremos mostrar.

                                                //Dentro del viewHolder vamos a colocar cada uno de los elementos que vallamos a procesar de la vista que para este caso es la
                                                //vista layout que creamos y que llamamos activity_item_lista_personalizada_recycler.xml. A continuación hacemos lo descrito
                                                //anteriormente.

        TextView nombre;
        TextView descripcion;
        TextView precio;
        TextView valorObsequios;
        ImageView imagenProducto;

        public CategoriaViewHolder(@NonNull View itemView) { //Este es un constructor por defecto que es necesario implementar y que recibe un view
            super(itemView);
            // A continuación creamos el vinculo de las variables creadas anteriormete con los componentes visuales de la vista layout activity_item_lista_personalizada_recycler.xml.
            this.nombre = itemView.findViewById(R.id.lbNombreCardViewRecycler);
            this.descripcion = itemView.findViewById(R.id.lbDescripcionCardViewRecycler);
            this.precio = itemView.findViewById(R.id.lbPrecioCardViewRecycler);
            this.valorObsequios = itemView.findViewById(R.id.lbValorObsequiosCardViewRecycler);
            this.imagenProducto = itemView.findViewById(R.id.imageCardViewRecycler);
        }


        public void bind(final Categorias categoria, final OnItemClickListenerRecyclerView listenerRecyclerView) {
            this.nombre.setText(categoria.getNombre());
            this.descripcion.setText(categoria.getDescripcion());
            //this.precio.setText(categoria.getprecio); // toca adaptar la clase (entidad) Categorias para agregar el atributo precio con sus metodos getter y setter.
            //this.valorObsequios.setText(categoria.getValorObsequios); // toca adaptar la clase (entidad) Categorias para agregar el atributo valorObsequios con sus metodos getter y setter.
            Picasso.get().load(categoria.getUrlImagen()).into(this.imagenProducto);
            this.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    listenerRecyclerView.onItemClickRecyclerView(categoria);
                }
            });
        }
    }

    @NonNull
    @Override
    public CategoriaViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View vista = LayoutInflater.from(parent.getContext())
        .inflate(R.layout.activity_item_lista_personalizada_recycler, parent, false);// / inflate es el metodo
        // que usamos para inflar o para cargar el layout personalizado que creamos y lo colocamos en el contexto actual para
        // representar la información. En este caso el contexto lo sacamos de la variable parent de tipo ViewGroup

        CategoriaViewHolder categoriaViewHolder = new CategoriaViewHolder(vista);

        return categoriaViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull CategoriaViewHolder holder, int position) { //Este metodo tiene como función asociar los datos dinamicos del objeto categoria
                                                                            //correspondiente a los elementos de la vista layout activity_item_lista_personalizada_recycler.xml.
                                                                // y esos datos son los que se van a mostrar al usuario.
        Categorias categoria = this.categorias.get(position);
       /*
        holder.nombre.setText(categoria.getNombre());
        holder.descripcion.setText(categoria.getDescripcion());
        //holder.precio.setText(categoria.getprecio); // toca adaptar la clase (entidad) Categorias para agregar el atributo precio con sus metodos getter y setter.
        //holder.valorObsequios.setText(categoria.getValorObsequios); // toca adaptar la clase (entidad) Categorias para agregar el atributo valorObsequios con sus metodos getter y setter.
        Picasso.get().load(categoria.getUrlImagen()).into(holder.imagenProducto);

        */
        holder.bind(categoria, listenerRecyclerView);
    }

    @Override
    public int getItemCount() {
        return this.categorias.size(); // retorna la cantidad de elementos que contiene el ArrayList categorias
    }

    //Creamos una interface interna para implementar la funcionalizad de escucha de los eventos clic sobre los items de la lista =>

    public interface OnItemClickListenerRecyclerView{ // con esta interface con lacual se va a generar el proceso de comunicación
        void onItemClickRecyclerView(Categorias categoria);
    }
}
