package co.com.personal.hnino.ejerciciosenclase;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

import co.com.personal.hnino.ejerciciosenclase.entidades.Categorias;

public class ListaPersonalizadaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_personalizada);

        /* ---------------------------- INICIO => BLOQUE DE CODICO PARA LISTA PERSONALIZADA -----------------------------------*/

        CategoriaAdapter adapterPersonalizado = new CategoriaAdapter(getApplicationContext(), DataTemporal.CATEGORIAS); // en este caso no tenemos que decirle la forma en la que queremos
                                            //presentar la información, ya que en la implementación de la clase CategoriaAdapter se le configuro la presentación que esta asociada
                                        //al layout Activity_item_lista_personalizada_uno

        final ListView listaProducts = findViewById(R.id.listViewProductosPersonalisado); // Se declara como tipo final para que en el metodo anonimo
        //existente dentro de listaProducts.setOnItemClickListener se pueda accedr a esta variable

        listaProducts.setAdapter(adapterPersonalizado);

        // Para que se viera la imagen por degecto, en el layout activity_item_lista_personalizada_uno.xml se ambio app: por  android:src
        // y actualmente la linea quedo android:src="@drawable/img_comestibles_defecto_1000x1500"

        /* ---------------------------- FIN => BLOQUE DE CODIGO PARA LISTA PERSONALIZADA -----------------------------------*/
    }
}