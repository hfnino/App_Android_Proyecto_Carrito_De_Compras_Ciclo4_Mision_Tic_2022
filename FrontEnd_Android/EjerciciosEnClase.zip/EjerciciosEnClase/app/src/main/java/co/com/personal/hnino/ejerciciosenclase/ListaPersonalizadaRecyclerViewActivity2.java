package co.com.personal.hnino.ejerciciosenclase;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import co.com.personal.hnino.ejerciciosenclase.entidades.Categorias;

public class ListaPersonalizadaRecyclerViewActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_personalizada_recycler_view_2);

        RecyclerView listaRecycler2 = findViewById(R.id.listaRecycler2); //El RecyclerView es un witget de android, es una vista de grupo (ViewGroup) ya que
        // es un contenedor que nos permite mostrar un listado (ListView) o una grilla (gridView) de elementos. El RecyclerView es una versión mejorada de la
        // clase ListView y lleva este nombre porque a medida que se renderizan los elementos de la lista, los elementos que dejan de observarse se reciclan
        // o se reutilizan para mostrar los elementos siguientes mejorando los tiempos de carga y respuesta ya que se cargan en memoria solo los elementos
        // visibles en ese momento, mientas que el ListView carga todos los elementos.

        //Para implementar el RecyclerView debemos agregar la librería de RecyclerView en el gradle:

        //implementation 'androidx.recyclerview:recyclerview:1.2.1'

        LinearLayoutManager linearLayout = new LinearLayoutManager(getApplicationContext()); // el RecyclerView maneja por defecto un layout tipo LinearLayout

        listaRecycler2.setLayoutManager(linearLayout); // linearLayout que es de la clase linearLayoutManager es el que nos va a manejar el contenido
                                            //de nuestro RecyclerView
        /*
        // EL RecyclerView siempre va a necesitar un adaptador ya que no cuenta con adaptadores predefinidos como si los hay para las ListView como es el caso del ArrayAdapter,
        por esto es que el adaptador creado a continuación no nos sirve.
        ArrayAdapter<Categorias> adapterRecyclerView = new ArrayAdapter<>(
                getApplicationContext(),
                android.R.layout.simple_list_item_1,
                DataTemporal.CATEGORIAS
        );

        listaRecycler.setAdapter(adapterRecyclerView);
        */

        CategoriaAdapterRecycler2 adapterRecyclerView2 = new CategoriaAdapterRecycler2(
                DataTemporal.CATEGORIAS,
                new CategoriaAdapterRecycler2.OnItemClickListenerRecyclerView2() {  // El metod .OnItemClickListenerRecyclerView2() es
                    // la interface que creamos en la clase CategoriaAdapterRecycler2 que contiene 2 metodos abstractos que debemos implementar y que lo hacemos acontinuación

                                       @Override
                    public void onItemClickRecyclerView2BtnAgregar(Categorias categoria) {
                        DataTemporal.CATEGORIAS_INTERES.add(categoria);
                        Log.i("====> Categoria seleccionada => ", categoria.getNombre());
                        Toast.makeText(getApplicationContext(), " ==== Se adicino al Spinner la categoria: " + categoria.getNombre(), Toast.LENGTH_LONG).show();
                    }

                    @Override
                    public void onItemClickRecyclerView2ImagenProducto(Categorias categoria) {
                        Log.i("====> Has hecho click en la imagen de la categoria :", categoria.getNombre());
                        Toast.makeText(getApplicationContext(), " ====> Has hecho click en la imagen de la categoria : " + categoria.getNombre(), Toast.LENGTH_LONG).show();
                    }


                }
        );

        listaRecycler2.setAdapter(adapterRecyclerView2);

        // En el ReciclerView al ser un componente externo, no cuenta un metodo de escucha para los eventos click como es el caso del OnItemViewListener en los ListView
        // por tanto se hace oblicatorio que en la creacion del adaptador personalozado usado por el ReciclerView, se implemente un metodo que realice la escucha de los
        //eventos click que para este prollecto lo creamos dentro del codico de la clase CategoriaAdapterRecycler

        listaRecycler2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.i("======> View = ", "" + view.toString());
            }
        });

    }
}