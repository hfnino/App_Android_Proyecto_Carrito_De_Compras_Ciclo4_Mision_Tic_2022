package co.com.personal.hnino.appmidespensa;

public class Config {

    public static final String IP_SERVER = "http://186.83.80.254:8084/";
    public static final String URL_VOLLEY_LOGIN = IP_SERVER + "Proyecto_Final_ciclo4_mi_despensa_RestJR/services/midespensa/validarUsuario";
    public static final String URL_VOLLEY_LOGIN_NEW_USER = IP_SERVER + "Proyecto_Final_ciclo4_mi_despensa_RestJR/services/midespensa/validarCrearUsuario";
    public static final String URL_VOLLEY_PRODUCTOS_CATEGORIA = IP_SERVER + "Proyecto_Final_ciclo4_mi_despensa_RestJR/services/midespensa/verProductosPorTipo?";
    public static final String URL_VOLLEY_PEDIDO_ACTUAL = IP_SERVER + "Proyecto_Final_ciclo4_mi_despensa_RestJR/services/midespensa/crearPedido";
    public static final String URL_VOLLEY_ADD_PRODUCTO_PEDITO = IP_SERVER + "Proyecto_Final_ciclo4_mi_despensa_RestJR/services/midespensa/addProductoEnCarrito";
    public static final String URL_VOLLEY_LINK_IMG = IP_SERVER + "Proyecto_Final_ciclo4_mi_despensa_RestJR/";
    public static final String URL_VOLLEY_CANT_PRODUCTOS_CARRITO_X_TIPO = IP_SERVER + "Proyecto_Final_ciclo4_mi_despensa_RestJR/services/midespensa/cantidadProductosCarrito?";
    public static final String URL_VOLLEY_CANT_PRODUCTOS_REPETIDOS_CARRITO = IP_SERVER + "Proyecto_Final_ciclo4_mi_despensa_RestJR/services/midespensa/cantidadProductosRepetidosCarrito?";
    public static final String URL_VOLLEY_LISTA_PRODUCTOS_EN_CARRITO = IP_SERVER + "Proyecto_Final_ciclo4_mi_despensa_RestJR/services/midespensa/verProductosEnCarritoCompras?";
    public static final String URL_VOLLEY_CANT_PRODUCTOS_SACADOS_DEL_CARRITO = IP_SERVER + "Proyecto_Final_ciclo4_mi_despensa_RestJR/services/midespensa/cantidadProductosSacadosCarrito?";
    public static final String URL_VOLLEY_RETIRAR_PRODUCTO_CARRITO = IP_SERVER + "Proyecto_Final_ciclo4_mi_despensa_RestJR/services/midespensa/retirarProductoDelCarrito?";
    public static final String URL_VOLLEY_CONFIRMAR_PAGO = IP_SERVER + "Proyecto_Final_ciclo4_mi_despensa_RestJR/services/midespensa/vistaConfirmacionPago?";

}
