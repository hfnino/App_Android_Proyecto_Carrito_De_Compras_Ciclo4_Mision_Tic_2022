package co.com.personal.hnino.appmidespensa;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;


import co.com.personal.hnino.appmidespensa.entidades.Pedidos;
import co.com.personal.hnino.appmidespensa.http.Singleton;

public class MenuPrincipalActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_principal);

        JSONObject dataSolicitud = new JSONObject();
        try {
            dataSolicitud = new JSONObject(DataTemporal.usuarioPerfil.toJson());
        } catch (JSONException e) {
            Toast.makeText(getApplicationContext(), " ===> Error transformando los datos ingresados a JSON", Toast.LENGTH_SHORT).show();
        }

        JsonObjectRequest solicitudCrearPedido = new JsonObjectRequest(
                Request.Method.POST,
                Config.URL_VOLLEY_PEDIDO_ACTUAL,
                dataSolicitud,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {

                        try {
                            Gson gson = new Gson();
                            Type tipo = new TypeToken<Pedidos>() {}.getType();
                            DataTemporal.pedidoActual = gson.fromJson(response.toString(), tipo);
                        }
                        catch (Exception e) {
                            Toast.makeText(getApplicationContext(), " =====> ERROOOOOOR EN SOLICITUD HTTP DE CREAR PEDIDO =( ", Toast.LENGTH_SHORT).show();
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), "=====> Respuesta de Error de URL_VOLLEY_PEDIDO_ACTUAL - response.toString(): " + error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
        );

        Singleton.getInstance(getApplicationContext()).addToRequestQueue(solicitudCrearPedido);

        Button btnCerrarSesion = findViewById(R.id.btnCerrarSesion);

        btnCerrarSesion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intentCerrarSesion = new Intent(getApplicationContext(), MainActivity.class);
                intentCerrarSesion.addFlags(intentCerrarSesion.FLAG_ACTIVITY_CLEAR_TASK);
                intentCerrarSesion.addFlags(intentCerrarSesion.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intentCerrarSesion);
            }
        });
    }

    public void listadoProductosComestibles(View ProductosComestibles){

        String tipoCategoria = "1";

        Intent intentListaProductosCategoriaActivity = new Intent(MenuPrincipalActivity.this, ListaProductosCategoriaRecyclerViewActivity.class);

        intentListaProductosCategoriaActivity.putExtra("numTipoCategoria", tipoCategoria);

        cardViewComestibles.launch(intentListaProductosCategoriaActivity);

    }

    ActivityResultLauncher<Intent> cardViewComestibles = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult resultado) {
                    if(resultado.getResultCode() == RESULT_OK){
                        Toast.makeText(getApplicationContext(), "has regresado al menú principal ", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        Toast.makeText(getApplicationContext(), " ====> Error: Algo Paso", Toast.LENGTH_SHORT).show();
                    }
                }
            }
    );

    public void listadoProductosLiquidos(View ProductosLiquidos){

        String tipoCategoria = "2";

        Intent intentListaProductosCategoriaActivity = new Intent(MenuPrincipalActivity.this, ListaProductosCategoriaRecyclerViewActivity.class);

        intentListaProductosCategoriaActivity.putExtra("numTipoCategoria", tipoCategoria);
        cardViewLiquidos.launch(intentListaProductosCategoriaActivity);
    }

    ActivityResultLauncher<Intent> cardViewLiquidos = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult resultado) {

                    if(resultado.getResultCode() == RESULT_OK){
                        Toast.makeText(getApplicationContext(), "has regresado al menú principal ", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        Toast.makeText(getApplicationContext(), " ====> Error: Algo Paso", Toast.LENGTH_SHORT).show();
                    }
                }
            }
    );

    public void listadoProductosAseo(View ProductosAseo){

        String tipoCategoria = "3";

        Intent intentListaProductosCategoriaActivity = new Intent(MenuPrincipalActivity.this, ListaProductosCategoriaRecyclerViewActivity.class);

        intentListaProductosCategoriaActivity.putExtra("numTipoCategoria", tipoCategoria);

        cardViewAseo.launch(intentListaProductosCategoriaActivity);

    }

    ActivityResultLauncher<Intent> cardViewAseo = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult resultado) {

                    if(resultado.getResultCode() == RESULT_OK){
                        Toast.makeText(getApplicationContext(), "has regresado al menú principal ", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        Toast.makeText(getApplicationContext(), " ====> Error: Algo Paso", Toast.LENGTH_SHORT).show();
                    }
                }
            }
    );

    public void listadoProductosPromocion(View ProductosPromocion){

        String tipoCategoria = "4";

        Intent intentListaProductosCategoriaActivity = new Intent(MenuPrincipalActivity.this, ListaProductosCategoriaRecyclerViewActivity.class);

        intentListaProductosCategoriaActivity.putExtra("numTipoCategoria", tipoCategoria);

        cardViewPromociones.launch(intentListaProductosCategoriaActivity);

    }

    ActivityResultLauncher<Intent> cardViewPromociones = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult resultado) {

                    if(resultado.getResultCode() == RESULT_OK){
                        Toast.makeText(getApplicationContext(), "has regresado al menú principal ", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        Toast.makeText(getApplicationContext(), " ====> Error: Algo Paso", Toast.LENGTH_SHORT).show();
                    }
                }
            }
    );

    public void datosDePerfil(View perfil){

        Intent intentPerfilDeUsuarioActivity = new Intent(MenuPrincipalActivity.this, PerfilDeUsuarioActivity.class);

        btnDatosDePerfil.launch(intentPerfilDeUsuarioActivity);

    }

    ActivityResultLauncher<Intent> btnDatosDePerfil = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult resultado) {

                    if(resultado.getResultCode() == RESULT_OK){
                        Toast.makeText(getApplicationContext(), "has regresado al menú principal ", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        Toast.makeText(getApplicationContext(), " ====> Error: Algo Paso", Toast.LENGTH_SHORT).show();
                    }
                }
            }
    );

    public void solicitudhttpCantidadProductosEnCarritoXTipo(View cantidadProductosEnCarritoXTipo) {

        StringRequest solicitudCantidadProductosEnCarritoXTipo = new StringRequest(
                Request.Method.GET,
                Config.URL_VOLLEY_CANT_PRODUCTOS_CARRITO_X_TIPO +
                        "id=" + DataTemporal.pedidoActual.getId() + "&id_usuario=" + DataTemporal.usuarioPerfil.getId(),
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(getApplicationContext(), response, Toast.LENGTH_LONG).show();

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), " ===> Error: Algo paso en la solicitud 'solicitudCantidadProductosEnCarritoXTipo' HTTP via GET", Toast.LENGTH_LONG).show();
                    }
                }
        )
        {

        };

        Singleton.getInstance(getApplicationContext()).addToRequestQueue(solicitudCantidadProductosEnCarritoXTipo);
    }

    public void solicitudhttpCantidadProductosRepetidosEnCarrito(View cantidadProductosRepetidosEnCarrito){

        StringRequest solicitudCantidadProductosRepetidosEnCarrito = new StringRequest(
                Request.Method.GET,
                Config.URL_VOLLEY_CANT_PRODUCTOS_REPETIDOS_CARRITO +
                        "id=" + DataTemporal.pedidoActual.getId() + "&id_usuario=" + DataTemporal.usuarioPerfil.getId(),
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(getApplicationContext(), response, Toast.LENGTH_LONG).show();

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                         Toast.makeText(getApplicationContext(), " ===> Error: Algo paso en la solicitud 'solicitudCantidadProductosRepetidosEnCarrito' HTTP via GET", Toast.LENGTH_LONG).show();
                    }
                }
        )
        {

        };

        Singleton.getInstance(getApplicationContext()).addToRequestQueue(solicitudCantidadProductosRepetidosEnCarrito);
    }

    public void solicitudhttpCantidadProductosSacadosDelCarrito(View cantidadProductosSacadosDelCarrito){

        StringRequest solicitudCantidadProductosSacadosDelCarrito = new StringRequest(
                Request.Method.GET,
                Config.URL_VOLLEY_CANT_PRODUCTOS_SACADOS_DEL_CARRITO +
                        "id=" + DataTemporal.pedidoActual.getId() + "&id_usuario=" + DataTemporal.usuarioPerfil.getId(),
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(getApplicationContext(), response, Toast.LENGTH_LONG).show();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), " ===> Error: Algo paso en la solicitud 'solicitudCantidadProductosSacadosDelCarrito' HTTP via GET", Toast.LENGTH_LONG).show();
                    }
                }
        )
        {

        };

        Singleton.getInstance(getApplicationContext()).addToRequestQueue(solicitudCantidadProductosSacadosDelCarrito);
    }


    public void listadoProductosEnCarrito(View ProductosEnCarrito){

        Intent intentListaProductosCarritoActivity = new Intent(MenuPrincipalActivity.this, ListaProductosCarritoRecyclerViewActivity.class);

        btnVerEditarProductosEnCarrito.launch(intentListaProductosCarritoActivity);
    }

    ActivityResultLauncher<Intent> btnVerEditarProductosEnCarrito = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult resultado) {
                    if(resultado.getResultCode() == RESULT_OK){
                        Toast.makeText(getApplicationContext(), "has regresado al menú principal ", Toast.LENGTH_LONG).show();
                    }
                    else {
                        Toast.makeText(getApplicationContext(), " ===> Error: Algo paso ", Toast.LENGTH_LONG).show();
                    }
                }
            }
    );
}