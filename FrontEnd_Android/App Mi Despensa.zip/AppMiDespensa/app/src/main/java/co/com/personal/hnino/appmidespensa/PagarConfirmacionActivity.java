package co.com.personal.hnino.appmidespensa;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;

import co.com.personal.hnino.appmidespensa.entidades.Pedidos;
import co.com.personal.hnino.appmidespensa.entidades.Productos;
import co.com.personal.hnino.appmidespensa.entidades.Usuarios;
import co.com.personal.hnino.appmidespensa.http.Singleton;

public class PagarConfirmacionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pagar_confirmacion);

        JSONObject dataSolicitudPedido = new JSONObject();

        try {

            Gson gson = new Gson();
            Type tipo = new TypeToken<Pedidos>() {}.getType();
            String pedidoActualString = gson.toJson(DataTemporal.pedidoActual, tipo);

            dataSolicitudPedido = new JSONObject(pedidoActualString);
        }
        catch (JSONException e) {
            Toast.makeText(getApplicationContext(), " ===> Error transformando el objeto pedidoActualString a Json", Toast.LENGTH_SHORT).show();
        }

        JsonObjectRequest solicitudAgregarProductoAlPedido = new JsonObjectRequest(
                Request.Method.PUT,
                Config.URL_VOLLEY_CONFIRMAR_PAGO + "totalObsequios=" + DataTemporal.totalObsequios,
                dataSolicitudPedido,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {

                        if(response.toString().equals("{\"mensaje\":\"Pago_OK\"}")){
                            Toast.makeText(getApplicationContext(), "El pago se realizo exitosamente, Gracias por su Compra!\n\n" +
                                    "El valor de obsequios ha sido actualizado y puede verlo en los datos de su perfil", Toast.LENGTH_LONG).show();

                            TextView textViewConfirmacionValorObsequiosOptenidos = findViewById(R.id.textViewConfirmacionValorObsequiosOptenidos);
                            textViewConfirmacionValorObsequiosOptenidos.setText("Ud. ha ganado " + DataTemporal.totalObsequios + " por el concepto de obsequios");
                            DataTemporal.INVENTARIO_CARRITO_COMPRAS = new ArrayList<Productos>();
                            DataTemporal.precioTotalPagar = 0.0;
                            DataTemporal.totalObsequios = 0;

                            actualizarPerfilDeUsuario();

                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), "=====> Respuesta de Error de URL_VOLLEY_CONFIRMAR_PAGO - response.toString(): " + error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
        );

        Singleton.getInstance(getApplicationContext()).addToRequestQueue(solicitudAgregarProductoAlPedido);


        Button btnAceptar = findViewById(R.id.btnAceptarEnPagarConfirmacion);

        btnAceptar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setResult(RESULT_OK);

                Intent intentIrMenuPrincipalActivity = new Intent(getApplicationContext(), MenuPrincipalActivity.class);
                startActivity(intentIrMenuPrincipalActivity);
                finish();
            }
        });
    }

    private void actualizarPerfilDeUsuario() {

        JSONObject dataSolicitudActualizarPerfilDeUsuario = new JSONObject();
        try {
            dataSolicitudActualizarPerfilDeUsuario = new JSONObject(DataTemporal.usuarioPerfil.toJson());
        } catch (JSONException e) {
            Toast.makeText(getApplicationContext(), " ===> Error transformando los datos ingresados a JSON", Toast.LENGTH_SHORT).show();
        }

        JsonObjectRequest solicitudActualizarPerfilDeUsuario = new JsonObjectRequest(
                Request.Method.POST,
                Config.URL_VOLLEY_LOGIN_NEW_USER,
                dataSolicitudActualizarPerfilDeUsuario,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {

                        try {
                            Gson gson = new Gson();
                            Type tipo = new TypeToken<Usuarios>() {}.getType();
                            DataTemporal.usuarioPerfil = gson.fromJson(response.toString(), tipo);
                        }
                        catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), "=====> Respuesta de Error de URL_VOLLEY_LOGIN via POST - response.toString(): " + error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
        );

        Singleton.getInstance(getApplicationContext()).addToRequestQueue(solicitudActualizarPerfilDeUsuario);
    }
}