package co.com.personal.hnino.appmidespensa;

import java.util.ArrayList;

import co.com.personal.hnino.appmidespensa.entidades.CarritosPedidos;
import co.com.personal.hnino.appmidespensa.entidades.Pedidos;
import co.com.personal.hnino.appmidespensa.entidades.Productos;
import co.com.personal.hnino.appmidespensa.entidades.Usuarios;

public class DataTemporal {

    public static ArrayList<Productos> INVENTARIO_PRODUCTOS_CATEGORIA = new ArrayList<>();
    public static ArrayList<Productos> INVENTARIO_CARRITO_COMPRAS = new ArrayList<>();
    public static Usuarios usuarioValidar = new Usuarios();
    public static Usuarios usuarioPerfil = new Usuarios();
    public static Pedidos pedidoActual = new Pedidos();
    public static CarritosPedidos productoPedidoAddCarrito = new CarritosPedidos();
    public static CarritosPedidos productoPedidoRetirarCarrito = new CarritosPedidos();
    public static Double precioTotalPagar = 0.0;
    public static Integer totalObsequios = 0;

}
