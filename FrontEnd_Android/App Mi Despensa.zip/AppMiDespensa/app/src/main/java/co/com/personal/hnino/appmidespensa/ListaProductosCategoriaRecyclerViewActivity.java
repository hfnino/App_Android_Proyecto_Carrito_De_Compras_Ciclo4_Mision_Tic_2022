package co.com.personal.hnino.appmidespensa;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;

import co.com.personal.hnino.appmidespensa.entidades.CarritosPedidos;
import co.com.personal.hnino.appmidespensa.entidades.Pedidos;
import co.com.personal.hnino.appmidespensa.entidades.Productos;
import co.com.personal.hnino.appmidespensa.entidades.Usuarios;
import co.com.personal.hnino.appmidespensa.http.Singleton;

public class ListaProductosCategoriaRecyclerViewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_lista_productos_categoria_recycler_view);

        String numTipoCategoria = getIntent().getStringExtra("numTipoCategoria");

        TextView txtCategoria = findViewById(R.id.textViewRecyclerView);

        ArrayList<Productos> listaProductosCategoria = new ArrayList<>();

        if (numTipoCategoria.equals("1")){
            txtCategoria.setText("Pasillo de Productos Comestibles");
            listaProductosCategoria(1);
        }

        if (numTipoCategoria.equals("2")){
            txtCategoria.setText("Pasillo de Productos Liquidos");
            listaProductosCategoria(2);
        }

        if (numTipoCategoria.equals("3")){
            txtCategoria.setText("Pasillo de Productos de Aseo");
            listaProductosCategoria(3);
        }

        if (numTipoCategoria.equals("4")){
            txtCategoria.setText("Pasillo de Productos en Promoción ");
            listaProductosCategoria(4);
        }

        Button btnRegresar = findViewById(R.id.btnRegresarEnListadoProductosCategoria);

        btnRegresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setResult(RESULT_OK);
                finish();
            }
        });
    }

    private void listaProductosCategoria(int categoriaTipoProductos) {

        StringRequest solicitudProductosCategoria = new StringRequest(
                Request.Method.GET,
                Config.URL_VOLLEY_PRODUCTOS_CATEGORIA + "tipoProductos=" + categoriaTipoProductos,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        Gson gson = new Gson();
                        Type tipo = new TypeToken<ArrayList<Productos>>() {}.getType();
                        DataTemporal.INVENTARIO_PRODUCTOS_CATEGORIA = gson.fromJson(response.toString(), tipo);

                        RecyclerView listaRecyclerProductos = findViewById(R.id.listaRecyclerProductos);

                        LinearLayoutManager linearLayout = new LinearLayoutManager(getApplicationContext());

                        listaRecyclerProductos.setLayoutManager(linearLayout);

                        AdapterProductosCategoriaRecycler adapterRecyclerViewProductos = new AdapterProductosCategoriaRecycler(
                                DataTemporal.INVENTARIO_PRODUCTOS_CATEGORIA,
                                new AdapterProductosCategoriaRecycler.OnItemClickListenerRecyclerView() {

                                    @Override
                                    public void onItemClickRecyclerView2BtnAgregar(Productos producto) {
                                        solicitudAddProductoAlCarrito(producto);
                                        Toast.makeText(getApplicationContext(), " ==== El producto seleccionado se agregó al Carrito de compras: " + producto.getNombreProducto(), Toast.LENGTH_SHORT).show();
                                    }

                                    @Override
                                    public void onItemClickRecyclerView2ImagenProducto(Productos productos) {
                                        Toast.makeText(getApplicationContext(), " ====> Has hecho click en la imagen del producto: " + productos.getNombreProducto(), Toast.LENGTH_SHORT).show();
                                    }
                                }
                        );

                        listaRecyclerProductos.setAdapter(adapterRecyclerViewProductos);

                        listaRecyclerProductos.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                            }
                        });
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }
        );

        Singleton.getInstance(getApplicationContext()).addToRequestQueue(solicitudProductosCategoria);

    }


    public void solicitudAddProductoAlCarrito(Productos producto){

        DataTemporal.productoPedidoAddCarrito.setIdPedido(DataTemporal.pedidoActual.getId());
        DataTemporal.productoPedidoAddCarrito.setIdProducto(producto.getId());

        JSONObject dataSolicitud = new JSONObject();
        try {

            Gson gson = new Gson();
            Type tipo = new TypeToken<CarritosPedidos>() {}.getType();
            String productoPedidoAddCarritoString = gson.toJson(DataTemporal.productoPedidoAddCarrito, tipo);

            dataSolicitud = new JSONObject(productoPedidoAddCarritoString);
        }
        catch (JSONException e) {
            Toast.makeText(getApplicationContext(), " ===> Error transformando el objeto productoPedidoAddCarrito a Json", Toast.LENGTH_SHORT).show();
        }

        JsonObjectRequest solicitudAgregarProductoAlPedido = new JsonObjectRequest(
                Request.Method.POST,
                Config.URL_VOLLEY_ADD_PRODUCTO_PEDITO,
                dataSolicitud,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                        Toast.makeText(getApplicationContext(), "=====> Respuesta de Error de URL_VOLLEY_ADD_PRODUCTO_PEDITO - response.toString(): " + error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
        );

        Singleton.getInstance(getApplicationContext()).addToRequestQueue(solicitudAgregarProductoAlPedido);

    }
}