package co.com.personal.hnino.appmidespensa;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import co.com.personal.hnino.appmidespensa.entidades.Productos;

public class AdapterProductosEnCarritoRecycler
        extends RecyclerView.Adapter<AdapterProductosEnCarritoRecycler.ProductosViewHolder> {

    ArrayList<Productos> productos;

    OnItemClickListenerRecyclerView listenerRecyclerView;

    public AdapterProductosEnCarritoRecycler(ArrayList<Productos> productos) {
        this.productos = productos;
    }

    public AdapterProductosEnCarritoRecycler(ArrayList<Productos> productos, OnItemClickListenerRecyclerView listenerRecyclerView) {
        this.productos = productos;
        this.listenerRecyclerView = listenerRecyclerView;
    }

    static  class  ProductosViewHolder extends RecyclerView.ViewHolder{

        ImageView imagenProducto;
        TextView nombreProducto;
        TextView codBarras;
        TextView precioConIva;
        TextView fechaVencimiento;
        TextView descuento;
        TextView precioFinal;
        TextView valorObsequios;
        Button btnRetirar;

        public ProductosViewHolder(@NonNull View itemView) {
            super(itemView);
            this.imagenProducto = itemView.findViewById(R.id.imageProductoCarritoCardViewRecycler);
            this.nombreProducto = itemView.findViewById(R.id.lbNombreProductoCarritoCardViewRecycler);
            this.codBarras = itemView.findViewById(R.id.lbCodBarrasProductoCarritoCardViewRecycler);
            this.fechaVencimiento = itemView.findViewById(R.id.lbFechaVencimientoProductoCarritoCardViewRecycler);
            this.precioConIva = itemView.findViewById(R.id.lbPrecioConIvaProductoCarritoCardViewRecycler);
            this.descuento = itemView.findViewById(R.id.lbDescuentoProductoCarritoCardViewRecycler);
            this.precioFinal = itemView.findViewById(R.id.lbPrecioProductoCarritoCardViewRecycler);
            this.valorObsequios = itemView.findViewById(R.id.lbValorObsequioProductoCarritoCardViewRecycler);
            this.btnRetirar = itemView.findViewById(R.id.btnRetirarCardViewRecycler);

        }

        public void bind(final Productos producto, final OnItemClickListenerRecyclerView listenerRecyclerView) {

            Picasso.get().load(Config.URL_VOLLEY_LINK_IMG + producto.getUrlImagen())
                    .placeholder(R.drawable.img_comestibles_defecto_1000x1500)
                    .error(R.drawable.bg_04)
                    .into(this.imagenProducto);

            this.nombreProducto.setText(producto.getNombreProducto() + " - " + producto.getMarca() + " (Cod: " + producto.getId() +")");
            this.codBarras.setText("Código de Barras: " + producto.getCodBarras());
            this.fechaVencimiento.setText("Fecha de vencimiento: " + producto.getfVencimiento());
            this.precioConIva.setText("Precio Unitario con IVA: " + producto.getPrecioConIva());
            this.descuento.setText("Descuento: " + (producto.getPrecioConIva()*producto.getDescuento()));
            this.precioFinal.setText("Precio a pagar: " + (producto.getPrecioConIva() - (producto.getPrecioConIva()*producto.getDescuento())));
            this.valorObsequios.setText("Valor de Obsequio: " + producto.getValorObsequio());
            this.btnRetirar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    listenerRecyclerView.onItemClickRecyclerViewBtnRetirarCarrito(producto);
                }
            });

            this.imagenProducto.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    listenerRecyclerView.onItemClickRecyclerViewImagenProductoCarrito(producto);
                }
            });
        }
    }

    @NonNull
    @Override
    public ProductosViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View vista = LayoutInflater.from(parent.getContext())
        .inflate(R.layout.activity_item_lista_personalizada_productos_en_carrito_recycler, parent, false);

        ProductosViewHolder productosViewHolder = new ProductosViewHolder(vista);

        return productosViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ProductosViewHolder holder, int position) {
        Productos producto = this.productos.get(position);

        holder.bind(producto, listenerRecyclerView);
    }

    @Override
    public int getItemCount() {
        return this.productos.size();
    }

    public interface OnItemClickListenerRecyclerView{
        void onItemClickRecyclerViewBtnRetirarCarrito(Productos productos);

        void onItemClickRecyclerViewImagenProductoCarrito(Productos productos);
    }
}
