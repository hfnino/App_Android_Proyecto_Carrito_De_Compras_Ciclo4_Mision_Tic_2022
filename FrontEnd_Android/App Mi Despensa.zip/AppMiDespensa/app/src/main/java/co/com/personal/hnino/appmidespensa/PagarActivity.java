package co.com.personal.hnino.appmidespensa;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class PagarActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pagar);

        if(DataTemporal.INVENTARIO_CARRITO_COMPRAS.size() == 0){
            Toast.makeText(getApplicationContext(), " ==> Actualmente, el carrito esta vacio, no es posible hacer el pago", Toast.LENGTH_SHORT).show();
        }
        else{

            for(int i = 0; i < DataTemporal.INVENTARIO_CARRITO_COMPRAS.size(); i++){

                DataTemporal.precioTotalPagar += (DataTemporal.INVENTARIO_CARRITO_COMPRAS.get(i).getPrecioConIva() - (DataTemporal.INVENTARIO_CARRITO_COMPRAS.get(i).getPrecioConIva()*DataTemporal.INVENTARIO_CARRITO_COMPRAS.get(i).getDescuento()));
                DataTemporal.totalObsequios += DataTemporal.INVENTARIO_CARRITO_COMPRAS.get(i).getValorObsequio();
            }

            TextView textViewValorPagar = findViewById(R.id.textViewValorPagar);
            textViewValorPagar.setText("El valor total a pagar es: " + DataTemporal.precioTotalPagar);

            TextView textViewValorObsequios = findViewById(R.id.textViewValorObsequios);
            textViewValorObsequios.setText("Si realiza la compra, el valor total de obsequios a obtener es: " + DataTemporal.totalObsequios);

        }

        String [] listaMediosDePago = {"---- Selecione un medio de pago ----", "Tarjeta de Credito", "Tarjeta Debito", "Nequi", "DaviPlata", "MercadoPago", "Bitcoin", "Etherium"};

        Spinner comboBoxMediosDePago = findViewById(R.id.spinnerMediosDePago);

        ArrayAdapter<String> adapterSpinnerComboBoxMediosPago = new ArrayAdapter<>(
                getApplicationContext(),
                android.R.layout.simple_spinner_item,
                listaMediosDePago
        );

        comboBoxMediosDePago.setAdapter(adapterSpinnerComboBoxMediosPago);

        Button btnRegresar = findViewById(R.id.btnRegresarEnPagar);

        btnRegresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setResult(RESULT_OK);
                DataTemporal.precioTotalPagar = 0.0;
                DataTemporal.totalObsequios = 0;
                finish();
            }
        });
    }

    public void pagarConfirmacion (View confirmacionPagarPedido){

        Intent intentPagarConfirmacionActivity = new Intent(getApplicationContext(), PagarConfirmacionActivity.class);

        btnPagarConfirmacion.launch(intentPagarConfirmacionActivity);

        finish();
    }

    ActivityResultLauncher<Intent> btnPagarConfirmacion = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult resultado) {
                    if(resultado.getResultCode() == RESULT_OK){
                        Toast.makeText(getApplicationContext(), "has regresado al menú principal ", Toast.LENGTH_LONG).show();
                    }
                    else {
                        Toast.makeText(getApplicationContext(), "Error: ALgo Paso ", Toast.LENGTH_LONG).show();
                    }
                }
            }
    );

}