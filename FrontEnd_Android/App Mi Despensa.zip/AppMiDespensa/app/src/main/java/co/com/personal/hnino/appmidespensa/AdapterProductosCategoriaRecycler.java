package co.com.personal.hnino.appmidespensa;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import co.com.personal.hnino.appmidespensa.entidades.Productos;

public class AdapterProductosCategoriaRecycler
        extends RecyclerView.Adapter<AdapterProductosCategoriaRecycler.ProductosViewHolder> {

    ArrayList<Productos> productos;

    OnItemClickListenerRecyclerView listenerRecyclerView;

    public AdapterProductosCategoriaRecycler(ArrayList<Productos> productos) {
        this.productos = productos;
    }

    public AdapterProductosCategoriaRecycler(ArrayList<Productos> productos, OnItemClickListenerRecyclerView listenerRecyclerView) {
        this.productos = productos;
        this.listenerRecyclerView = listenerRecyclerView;
    }

    static  class  ProductosViewHolder extends RecyclerView.ViewHolder{

        ImageView imagenProducto;
        TextView nombreProducto;
        TextView codBarras;
        TextView fechaVencimiento;
        TextView precioConIva;
        TextView descuento;
        TextView precioFinal;
        TextView valorObsequios;
        Button btnAgregar;

        public ProductosViewHolder(@NonNull View itemView) {
            super(itemView);
            this.imagenProducto = itemView.findViewById(R.id.imageProductoCardViewRecycler);
            this.nombreProducto = itemView.findViewById(R.id.lbNombreProductoCardViewRecycler);
            this.codBarras = itemView.findViewById(R.id.lbCodBarrasCardViewRecycler);
            this.fechaVencimiento = itemView.findViewById(R.id.lbFechaVencimientoProductoCardViewRecycler);
            this.precioConIva = itemView.findViewById(R.id.lbPrecioConIvaCardViewRecycler);
            this.descuento = itemView.findViewById(R.id.lbDescuentoProductoCategoriaCardViewRecycler);
            this.valorObsequios = itemView.findViewById(R.id.lbValorObsequioProductoCategoriaCardViewRecycler);
            this.precioFinal = itemView.findViewById(R.id.lbPrecioProductoCategoriaCardViewRecycler);
            this.btnAgregar = itemView.findViewById(R.id.btnAgregarCardViewRecycler2);
        }

        public void bind(final Productos producto, final OnItemClickListenerRecyclerView listenerRecyclerView) {

            Picasso.get().load(Config.URL_VOLLEY_LINK_IMG + producto.getUrlImagen())
                    .placeholder(R.drawable.img_comestibles_defecto_1000x1500)
                    .error(R.drawable.bg_04)
                    .into(this.imagenProducto);

            this.nombreProducto.setText(producto.getNombreProducto() + " - " + producto.getMarca() + " (Cod: " + producto.getId() +")");
            this.codBarras.setText("Código de Barras: " + producto.getCodBarras());
            this.fechaVencimiento.setText("Fecha de vencimiento: " + producto.getfVencimiento());
            this.precioConIva.setText("Precio Unitario con IVA: " + producto.getPrecioConIva());
            this.descuento.setText("Descuento: " + (producto.getPrecioConIva() * producto.getDescuento()));
            this.precioFinal.setText("Precio a pagar: " + (producto.getPrecioConIva() - (producto.getPrecioConIva()*producto.getDescuento())));
            this.valorObsequios.setText("Valor de Obsequio: " + producto.getValorObsequio());
            this.btnAgregar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    listenerRecyclerView.onItemClickRecyclerView2BtnAgregar(producto);
                }
            });

            this.imagenProducto.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    listenerRecyclerView.onItemClickRecyclerView2ImagenProducto(producto);
                }
            });
        }
    }

    @NonNull
    @Override
    public ProductosViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View vista = LayoutInflater.from(parent.getContext())
        .inflate(R.layout.activity_item_lista_personalizada_productos_categoria_recycler, parent, false);

        ProductosViewHolder productosViewHolder = new ProductosViewHolder(vista);

        return productosViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ProductosViewHolder holder, int position) {
        Productos producto = this.productos.get(position);
        holder.bind(producto, listenerRecyclerView);
    }

    @Override
    public int getItemCount() {
        return this.productos.size();
    }

    public interface OnItemClickListenerRecyclerView{
        void onItemClickRecyclerView2BtnAgregar(Productos productos);

        void onItemClickRecyclerView2ImagenProducto(Productos productos);
    }
}
