package co.com.personal.hnino.appmidespensa.entidades;

public class Proveedor {
    private String marca;
    private Integer categoria;

    public Proveedor(){

    }

    public Proveedor(String marca, Integer categoria) {
        this.marca = marca;
        this.categoria = categoria;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public Integer getCategoria() {
        return categoria;
    }

    public void setCategoria(Integer categoria) {
        this.categoria = categoria;
    }
}
