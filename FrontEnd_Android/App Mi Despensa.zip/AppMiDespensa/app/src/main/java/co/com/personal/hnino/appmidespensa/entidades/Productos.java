package co.com.personal.hnino.appmidespensa.entidades;

import co.com.personal.hnino.appmidespensa.R;

public class Productos extends Proveedor{

    private Integer id;
    private String codBarras;
    private String nombreProducto;
    private String fVencimiento;
    private Integer precioSinIva;
    private Float iva;
    private Integer precioConIva;
    private Double descuento;
    private Integer idEstado;
    private Integer valorObsequio;
    private String urlImagen = "" + R.drawable.carrito;

    public Productos(){

    }

    public Productos(Integer id, String codBarras, String nombreProducto, String marca, String fVencimiento,
                     Integer precioConIva, Double descuento, Integer idEstado,
                     Integer categoria) {

        super(marca, categoria);
        this.id = id;
        this.codBarras = codBarras;
        this.nombreProducto = nombreProducto;
        this.fVencimiento = fVencimiento;
        this.precioConIva = precioConIva;
        this.descuento = descuento;
        this.idEstado = idEstado;
        this.valorObsequio = (int)(((precioConIva - (precioConIva*descuento))/10000))*1000;
    }

    public Productos(Integer id, String codBarras, String nombreProducto, String marca,
            Integer precioConIva, Double descuento, Integer idEstado,
                     Integer categoria) {

        super(marca, categoria);
        this.id = id;
        this.codBarras = codBarras;
        this.nombreProducto = nombreProducto;
        this.precioConIva = precioConIva;
        this.descuento = descuento;
        this.idEstado = idEstado;
        this.valorObsequio = (int)(((precioConIva - (precioConIva*descuento))/10000))*1000;
    }
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCodBarras() {
        return codBarras;
    }

    public void setCodBarras(String codBarras) {
        this.codBarras = codBarras;
    }

    public String getNombreProducto() {
        return nombreProducto;
    }

    public void setNombreProducto(String nombreProducto) {
        this.nombreProducto = nombreProducto;
    }

    public String getfVencimiento() {
        return fVencimiento;
    }

    public void setfVencimiento(String fVencimiento) {
        this.fVencimiento = fVencimiento;
    }

    public Integer getPrecioSinIva() {
        return precioSinIva;
    }

    public void setPrecioSinIva(Integer precioSinIva) {
        this.precioSinIva = precioSinIva;
    }

    public Float getIva() {
        return iva;
    }

    public void setIva(Float iva) {
        this.iva = iva;
    }

    public Integer getPrecioConIva() {
        return precioConIva;
    }

    public void setPrecioConIva(Integer precioConIva) {
        this.precioConIva = precioConIva;
    }

    public Double getDescuento() {
        return descuento;
    }

    public void setDescuento(Double descuento) {
        this.descuento = descuento;
    }

    public Integer getValorObsequio() {
        return valorObsequio;
    }

    public void setValorObsequio(Integer valorObsequio) {
        this.valorObsequio = valorObsequio;
    }

    public Integer getIdEstado() {
        return idEstado;
    }

    public void setIdEstado(Integer idEstado) {
        this.idEstado = idEstado;
    }

    public String getUrlImagen() {
        return urlImagen;
    }

    public void setUrlImagen(String urlImagen) {
        this.urlImagen = urlImagen;
    }

    @Override
    public String toString() {
        return "Productos{" +
                "id=" + id +
                ", codBarras='" + codBarras + '\'' +
                ", nombreProducto='" + nombreProducto + '\'' +
                ", fVencimiento='" + fVencimiento + '\'' +
                ", precioSinIva=" + precioSinIva +
                ", iva=" + iva +
                ", precioConIva=" + precioConIva +
                ", descuento=" + descuento +
                ", idEstado=" + idEstado +
                ", valorObsequio=" + valorObsequio +
                ", urlImagen=" + urlImagen +
                '}';
    }
}
