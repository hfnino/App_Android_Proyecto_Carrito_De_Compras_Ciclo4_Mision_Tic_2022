package co.com.personal.hnino.appmidespensa;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;

import co.com.personal.hnino.appmidespensa.entidades.Usuarios;
import co.com.personal.hnino.appmidespensa.http.Singleton;

public class CrearCuentaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_crear_cuenta);

        EditText numIdentificacion = findViewById(R.id.txtNumIdentificacionCrearCuenta);
        numIdentificacion.setOnClickListener(eventoClick);

        EditText nombreCompleto = findViewById(R.id.txtNombreCompletoCrearCuenta);
        nombreCompleto.setOnClickListener(eventoClick);

        EditText correoE = findViewById(R.id.txtCorreoECrearCuenta);
        correoE.setOnClickListener(eventoClick);

        Button btnRegresar = findViewById(R.id.btnRegresarEnCrearCuenta);

        btnRegresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setResult(RESULT_OK);
                finish();
            }
        });
    }

    View.OnClickListener eventoClick = new View.OnClickListener() {

        @Override
        public void onClick(View view) {
            if (view.getId() == R.id.txtNumIdentificacionCrearCuenta){
                Toast.makeText(getApplicationContext(), "Ingrese su numero de identificación ", Toast.LENGTH_LONG).show();
            }
            else if (view.getId() == R.id.txtNombreCompletoCrearCuenta){
                Toast.makeText(getApplicationContext(), "Ingrese su nombre completo ", Toast.LENGTH_LONG).show();
            }
            else if(view.getId() == R.id.txtCorreoECrearCuenta){
                Toast.makeText(getApplicationContext(), "Ingrese su correo electronico ", Toast.LENGTH_LONG).show();
            }
        }
    };

    public void crearCuentaEIniciarSesion(View registro){

        String numIdentificacionString = "x";
        String nombreCompletoString = "y";
        Integer numIdentificacionInteger = 0;
        String correoEString = "";

        EditText numIdentificacion = findViewById(R.id.txtNumIdentificacionCrearCuenta);
        EditText nombreCompleto = findViewById(R.id.txtNombreCompletoCrearCuenta);
        EditText correoE = findViewById(R.id.txtCorreoECrearCuenta);

        numIdentificacionString = numIdentificacion.getText().toString();
        nombreCompletoString = nombreCompleto.getText().toString();
        correoEString = correoE.getText().toString();

        if (numIdentificacionString == null || numIdentificacionString.equalsIgnoreCase("x") || numIdentificacionString.equalsIgnoreCase("")
                || nombreCompletoString.equalsIgnoreCase("") || correoEString.equalsIgnoreCase("")) {

            Toast.makeText(getApplicationContext(), "Los datos para inicio de sesión no son validos o estan incompletos", Toast.LENGTH_LONG).show();
        }

        else {

            numIdentificacionInteger = Integer.parseInt(numIdentificacionString);

            DataTemporal.usuarioValidar.setCedula(numIdentificacionInteger);
            DataTemporal.usuarioValidar.setNombre(nombreCompletoString);
            DataTemporal.usuarioValidar.setCorreoE(correoEString);
            DataTemporal.usuarioValidar.setValorAcomuladoObsequios(0);
            DataTemporal.usuarioValidar.setEstado(0);

            JSONObject dataSolicitud = new JSONObject();

            try {
                dataSolicitud = new JSONObject(DataTemporal.usuarioValidar.toJson());
            }
            catch (JSONException e) {
                Toast.makeText(getApplicationContext(), " ===> Error transformando los datos ingresados a JSON", Toast.LENGTH_SHORT).show();
            }

            JsonObjectRequest solicitudValidarCrearUsuario = new JsonObjectRequest(
                    Request.Method.POST,
                    Config.URL_VOLLEY_LOGIN_NEW_USER,
                    dataSolicitud,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            try {

                                Gson gson = new Gson();
                                Type tipo = new TypeToken<Usuarios>() {}.getType();
                                DataTemporal.usuarioPerfil = gson.fromJson(response.toString(), tipo);

                                if (DataTemporal.usuarioPerfil.getCedula().equals(999999999)) {
                                    Toast.makeText(getApplicationContext(), " Error al conectar a la base de datos, por favor reporte el inconveniente a soporte@midespensa.com.co para resolverlo", Toast.LENGTH_LONG).show();
                                }

                                else if (DataTemporal.usuarioPerfil.getMensajes().equals("Cedula_OK")){
                                    Toast.makeText(getApplicationContext(), "Error: El usuario con el numero de identificación "
                                            + DataTemporal.usuarioPerfil.getCedula() + " ya se encuentra registrado, si no recuerda los datos " +
                                            "para inicio de sesión, por favor reporte la novedad al correo soporte@midespensa.com.co", Toast.LENGTH_LONG).show();
                                }

                                else if(DataTemporal.usuarioPerfil.getMensajes().equals(("CorreoE_OK"))) {
                                    Toast.makeText(getApplicationContext(), "Error: El usuario con la cuenta de correo "
                                            + DataTemporal.usuarioPerfil.getCorreoE() + " ya se encuentra registrado, si no recuerda los datos " +
                                            "para inicio de sesión, por favor reporte la novedad al correo soporte@midespensa.com.co", Toast.LENGTH_LONG).show();
                                }
                                else{

                                    Toast.makeText(getApplicationContext(), "Bienvenid@ " + DataTemporal.usuarioPerfil.getNombre() +", su cuenta ha sido creada con exito!", Toast.LENGTH_LONG).show();

                                    Intent intentActivityMenuPrincipal = new Intent(CrearCuentaActivity.this, MenuPrincipalActivity.class);

                                    lanzarAMenuPrincipal.launch(intentActivityMenuPrincipal);

                                    finish();

                                }
                            }
                            catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Toast.makeText(getApplicationContext(), "=====> Respuesta de Error de URL_VOLLEY_LOGIN via POST - response.toString(): " + error.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
            );

            Singleton.getInstance(getApplicationContext()).addToRequestQueue(solicitudValidarCrearUsuario);

        }

    }

    ActivityResultLauncher<Intent> lanzarAMenuPrincipal = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult resultado) {
                    if(resultado.getResultCode() == RESULT_OK){
                        Toast.makeText(getApplicationContext(), "Se ha cerrado sesión correctamente ", Toast.LENGTH_LONG).show();
                    }
                    else {
                        Toast.makeText(getApplicationContext(), " =====> Error:  Algo Paso ", Toast.LENGTH_LONG).show();
                    }
                }
            }
    );

}