package co.com.personal.hnino.appmidespensa;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class PerfilDeUsuarioActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil_de_usuario);

        TextView textViewIdUsuario = findViewById(R.id.textViewIdUsuario);
        TextView textViewNombreCompleto = findViewById(R.id.textViewNombreCompleto);
        TextView textViewNumIdentificacion = findViewById(R.id.textViewNumIdentificacion);
        TextView textViewCorreoE = findViewById(R.id.textViewCorreoE);
        TextView textViewValorAcomuladoObsequios = findViewById(R.id.textViewValorAcomuladoObsequios);
        TextView textViewEstadoUsuario = findViewById(R.id.textViewEstadoUsuario);
        TextView textViewIdPedidoActual = findViewById(R.id.textViewIdPedidoActual);

        textViewIdUsuario.setText("ID de Usuario: " + DataTemporal.usuarioPerfil.getId());
        textViewNombreCompleto.setText("Nombre: " + DataTemporal.usuarioPerfil.getNombre());
        textViewNumIdentificacion.setText("No. de Identificación: " + DataTemporal.usuarioPerfil.getCedula());
        textViewCorreoE.setText("Correo Electrónico " + DataTemporal.usuarioPerfil.getCorreoE() );
        textViewValorAcomuladoObsequios.setText("Valor Acumulado de Obsequios: " + DataTemporal.usuarioPerfil.getValorAcomuladoObsequios());
        textViewEstadoUsuario.setText("Esado de Usuario: " + DataTemporal.usuarioPerfil.getEstado());
        textViewIdPedidoActual.setText("ID Pedido Actual: " + DataTemporal.pedidoActual.getId());

        Button btnRegresar = findViewById(R.id.btnRegresarEnPerfilUser);

        btnRegresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setResult(RESULT_OK);
                finish();
            }
        });
    }
}