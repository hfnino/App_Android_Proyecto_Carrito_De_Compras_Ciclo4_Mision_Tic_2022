package co.com.personal.hnino.appmidespensa;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;

import co.com.personal.hnino.appmidespensa.entidades.Productos;
import co.com.personal.hnino.appmidespensa.http.Singleton;

public class ListaProductosCarritoRecyclerViewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_productos_carrito_recycler_view);

        StringRequest solicitudListaProductosEnCarrito = new StringRequest(
                Request.Method.GET,
                Config.URL_VOLLEY_LISTA_PRODUCTOS_EN_CARRITO +
                        "id=" + DataTemporal.pedidoActual.getId() + "&id_usuario=" + DataTemporal.usuarioPerfil.getId(),
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        Gson gson = new Gson();
                        Type tipo = new TypeToken<ArrayList<Productos>>() {}.getType();
                        DataTemporal.INVENTARIO_CARRITO_COMPRAS = gson.fromJson(response.toString(), tipo);

                        if(DataTemporal.INVENTARIO_CARRITO_COMPRAS.size() == 0){
                            Toast.makeText(getApplicationContext(), "Actualmente el carrito esta vacio", Toast.LENGTH_SHORT).show();
                        }
                        else {

                            RecyclerView listaRecyclerProductosCarrito = findViewById(R.id.listaRecyclerProductosEnCarrito);

                            LinearLayoutManager linearLayout = new LinearLayoutManager(getApplicationContext());

                            listaRecyclerProductosCarrito.setLayoutManager(linearLayout);

                            AdapterProductosEnCarritoRecycler adapterRecyclerViewProductosCarrito = new AdapterProductosEnCarritoRecycler(
                                    DataTemporal.INVENTARIO_CARRITO_COMPRAS,
                                    new AdapterProductosEnCarritoRecycler.OnItemClickListenerRecyclerView() {

                                        @Override
                                        public void onItemClickRecyclerViewBtnRetirarCarrito(Productos producto) {
                                            solicitudRetirarProductoDelCarrito(producto);

                                        }

                                        @Override
                                        public void onItemClickRecyclerViewImagenProductoCarrito(Productos productos) {
                                            Toast.makeText(getApplicationContext(), " ====> Has hecho click en la imagen del producto: " + productos.getNombreProducto(), Toast.LENGTH_SHORT).show();
                                        }

                                    }
                            );


                            listaRecyclerProductosCarrito.setAdapter(adapterRecyclerViewProductosCarrito);

                            listaRecyclerProductosCarrito.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {

                                }
                            });
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }
        );

        Singleton.getInstance(getApplicationContext()).addToRequestQueue(solicitudListaProductosEnCarrito);

        Button btnRegresar = findViewById(R.id.btnRegresarEnListadoProductosCarrito);

        btnRegresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setResult(RESULT_OK);
                finish();
            }
        });
    }

    public void solicitudRetirarProductoDelCarrito(Productos producto){

        DataTemporal.productoPedidoRetirarCarrito.setIdPedido(DataTemporal.pedidoActual.getId());
        DataTemporal.productoPedidoRetirarCarrito.setIdProducto(producto.getId());

        StringRequest solicitudDeleteProductoEnCarrito = new StringRequest(
                Request.Method.GET,
                Config.URL_VOLLEY_RETIRAR_PRODUCTO_CARRITO  +
                        "idPedido=" + DataTemporal.productoPedidoRetirarCarrito.getIdPedido() +
                        "&idProducto=" + DataTemporal.productoPedidoRetirarCarrito.getIdProducto(),
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        Toast.makeText(getApplicationContext(), response + ", la lista de productos en el carrito fue actualizada", Toast.LENGTH_LONG).show();

                        Intent intentListaProductosCarritoActivity = new Intent(getApplicationContext(), ListaProductosCarritoRecyclerViewActivity.class);

                        startActivity(intentListaProductosCarritoActivity);
                        finish();
                    }
                },

                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), " ===> Error: Algo paso en la solicitud 'solicitudDeleteProductoEnCarrito' HTTP via DELETE", Toast.LENGTH_LONG).show();
                    }
                }
        )
        {

        };

        Singleton.getInstance(getApplicationContext()).addToRequestQueue(solicitudDeleteProductoEnCarrito);

    }

    public void pagar (View pagarPedido){

        if(DataTemporal.INVENTARIO_CARRITO_COMPRAS.size() == 0){
            Toast.makeText(getApplicationContext(), " ==> Actualmente, el carrito esta vacio, no es posible hacer el pago", Toast.LENGTH_SHORT).show();
        }
        else {

            Intent intentPagarActivity = new Intent(ListaProductosCarritoRecyclerViewActivity.this, PagarActivity.class);

            btnPagar.launch(intentPagarActivity);

        }
    }

    ActivityResultLauncher<Intent> btnPagar = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult resultado) {

                    if(resultado.getResultCode() == RESULT_OK){
                        Toast.makeText(getApplicationContext(), "has regresado al carrito de compras ", Toast.LENGTH_LONG).show();
                    }
                    else {
                        Toast.makeText(getApplicationContext(), " ====> Error: Algo Paso ", Toast.LENGTH_LONG).show();
                    }
                }
            }
    );
}