package co.com.personal.hnino.appmidespensa.entidades;

public class Usuarios {
    private Integer id;
    private Integer cedula;
    private String nombre;
    private String correoE;
    private Integer valorAcomuladoObsequios;
    private Integer estado;
    private String mensajes;
    private boolean valido;

    public Usuarios(){
    }

    public Usuarios(Integer id, Integer cedula, String nombre, String correoE, Integer valorAcomuladoObsequios,
                    Integer estado, String mensajes, boolean valido) {

        this.id = id;
        this.cedula = cedula;
        this.nombre = nombre;
        this.correoE = correoE;
        this.valorAcomuladoObsequios = valorAcomuladoObsequios;
        this.estado = estado;
        this.mensajes = mensajes;
        this.valido = valido;
    }

    public Usuarios(Integer cedula, String nombre, String correoE, Integer valorAcomuladoObsequios) {
        this.cedula = cedula;
        this.nombre = nombre;
        this.correoE = correoE;
        this.valorAcomuladoObsequios = valorAcomuladoObsequios;
        this.estado = 1;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getCedula() {
        return cedula;
    }

    public void setCedula(Integer cedula) {
        this.cedula = cedula;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCorreoE() {
        return correoE;
    }

    public void setCorreoE(String correoE) {
        this.correoE = correoE;
    }

    public Integer getValorAcomuladoObsequios() {
        return valorAcomuladoObsequios;
    }

    public void setValorAcomuladoObsequios(Integer valorAcomuladoObsequios) {
        this.valorAcomuladoObsequios = valorAcomuladoObsequios;
    }

    public Integer getEstado() {
        return estado;
    }

    public void setEstado(Integer estado) {
        this.estado = estado;
    }

    public String getMensajes() {
        return mensajes;
    }

    public void setMensajes(String mensajes) {
        this.mensajes = mensajes;
    }

    public boolean isValido() {
        return valido;
    }

    public void setValido(boolean valido) {
        this.valido = valido;
    }

    public String toJson(){

        String dataUserJson = "";

        if(this.id != null && this.id != 0){
            dataUserJson += "\"id\":\"" + this.id + "\"";
        }

        if(this.cedula != null && this.cedula != 0){
            dataUserJson += (dataUserJson.length() > 0 ? "," : "") + "\"cedula\":\"" + this.cedula + "\"";
        }

        if(this.nombre != null){
            dataUserJson += (dataUserJson.length() > 0 ? "," : "") + "\"nombre\":\"" + this.nombre + "\"";
        }

        if(this.correoE != null){
            dataUserJson += (dataUserJson.length() > 0 ? "," : "") + "\"correoE\":\"" + this.correoE + "\"";
        }

        if(this.valorAcomuladoObsequios != null){
            dataUserJson += (dataUserJson.length() > 0 ? "," : "") + "\"valorAcomuladoObsequios\":\"" + this.valorAcomuladoObsequios + "\"";
        }

        if(this.estado != null){
            dataUserJson += (dataUserJson.length() > 0 ? "," : "") + "\"estado\":\"" + this.estado + "\"";
        }

        if(this.mensajes != null){
            dataUserJson += (dataUserJson.length() > 0 ? "," : "") + "\"mensajes\":\"" + this.mensajes + "\"";
        }

        dataUserJson += (dataUserJson.length() > 0 ? "," : "") + "\"valido\":\"" + this.valido + "\"";

        return "{" + dataUserJson + "}";
    }

    @Override
    public String toString() {
        return " ------- Usuarios ------- => {" +
                "id=" + id +
                ", cedula=" + cedula +
                ", nombre='" + nombre + '\'' +
                ", correoE='" + correoE + '\'' +
                ", valorAcomuladoObsequios=" + valorAcomuladoObsequios +
                ", estado=" + estado +
                ", mensajes='" + mensajes + '\'' +
                ", valido=" + valido +
                '}';
    }
}
