package co.com.personal.hnino.appmidespensa;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONException;
import org.json.JSONObject;

import co.com.personal.hnino.appmidespensa.http.Singleton;

public class MainActivity extends AppCompatActivity {

    private RequestQueue queue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText numIdentificacion = findViewById(R.id.txtNumIdentificacion);
        numIdentificacion.setOnClickListener(eventoClick);

        EditText correoE = findViewById(R.id.txtCorreoE);
        correoE.setOnClickListener(eventoClick);

        Button btnSalir = findViewById(R.id.btnSalir);
        btnSalir.setOnClickListener(eventoClick);

        TextView txtViewCrearCuenta = findViewById(R.id.txtViewCrearCuenta);
        txtViewCrearCuenta.setOnClickListener(eventoClick);
    }

    View.OnClickListener eventoClick = new View.OnClickListener() {

        @Override
        public void onClick(View view) {

            if (view.getId() == R.id.txtNumIdentificacion){
                Toast.makeText(getApplicationContext(), "Ingrese su numero de identificación ", Toast.LENGTH_LONG).show();
            }

            else if(view.getId() == R.id.txtCorreoE){
                Toast.makeText(getApplicationContext(), "Ingrese su correo electronico ", Toast.LENGTH_LONG).show();
            }

            else if(view.getId() == R.id.btnSalir){
                Toast.makeText(getApplicationContext(), "La App ha Finalizado", Toast.LENGTH_LONG).show();
                MainActivity.super.finish();
            }

            else if(view.getId() == R.id.txtViewCrearCuenta){

                    Intent intentCrearCuentaActivity = new Intent(MainActivity.this, CrearCuentaActivity.class);

                    lanzarViewCrearCuenta.launch(intentCrearCuentaActivity);
            }

        }
    };

    @Override
    public void finish() {
    }

    ActivityResultLauncher<Intent> lanzarViewCrearCuenta = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult resultado) {

                    if(resultado.getResultCode() == RESULT_OK){
                        Toast.makeText(getApplicationContext(), "has regresado al formulario de inicio de sesión", Toast.LENGTH_LONG).show();
                    }
                    else {
                        Toast.makeText(getApplicationContext(), "Error:   Algo Paso", Toast.LENGTH_LONG).show();
                    }
                }
            }
    );

    public void iniciarSesion(View registro) {

        String numIdentificacionString = "x";
        Integer numIdentificacionInteger = 0;
        String correoEString = "";

        EditText numIdentificacion = findViewById(R.id.txtNumIdentificacion);
        EditText correoE = findViewById(R.id.txtCorreoE);

        numIdentificacionString = numIdentificacion.getText().toString();
        correoEString = correoE.getText().toString();

        if (numIdentificacionString == null || numIdentificacionString.equalsIgnoreCase("x")|| numIdentificacionString.equalsIgnoreCase("")
                || correoEString.equalsIgnoreCase("")) {

            Toast.makeText(getApplicationContext(), "\"Los datos para inicio de sesión no son validos o estan incompletos\"", Toast.LENGTH_LONG).show();

        }
        else {
            numIdentificacionInteger = Integer.parseInt(numIdentificacionString);

            DataTemporal.usuarioValidar.setCedula(numIdentificacionInteger);
            DataTemporal.usuarioValidar.setNombre("Texto de Usuario Auxiliar para Validar");
            DataTemporal.usuarioValidar.setCorreoE(correoEString);
            DataTemporal.usuarioValidar.setEstado(0);

            JSONObject data = new JSONObject();

            try {
                data = new JSONObject(DataTemporal.usuarioValidar.toJson());
            }
            catch (JSONException e) {
                Toast.makeText(getApplicationContext(), " ===> Error transformando los datos ingresados a JSON", Toast.LENGTH_SHORT).show();
            }

            JsonObjectRequest solicitudValidarUsuario = new JsonObjectRequest(
                    Request.Method.POST,
                    Config.URL_VOLLEY_LOGIN,
                    data,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            try {
                                JSONObject jsonObjectRecibido = response;

                                DataTemporal.usuarioPerfil.setId(jsonObjectRecibido.getInt("id"));
                                DataTemporal.usuarioPerfil.setCedula(jsonObjectRecibido.getInt("cedula"));
                                DataTemporal.usuarioPerfil.setNombre(jsonObjectRecibido.getString("nombre"));
                                DataTemporal.usuarioPerfil.setCorreoE(jsonObjectRecibido.getString("correoE"));
                                DataTemporal.usuarioPerfil.setValorAcomuladoObsequios(jsonObjectRecibido.getInt("valorAcomuladoObsequios"));
                                DataTemporal.usuarioPerfil.setEstado(jsonObjectRecibido.getInt("estado"));
                                DataTemporal.usuarioPerfil.setMensajes(jsonObjectRecibido.getString("mensajes"));
                                DataTemporal.usuarioPerfil.setValido(jsonObjectRecibido.getBoolean("valido"));

                                if (DataTemporal.usuarioPerfil.getCedula().equals(999999999)) {
                                    Toast.makeText(getApplicationContext(), " Error al conectar a la base de datos, por favor reporte el inconveniente a soporte@midespensa.com.co para resolverlo", Toast.LENGTH_LONG).show();

                                }

                                else if (DataTemporal.usuarioPerfil.getMensajes().equals("Cedula_OK_y_CorreoE_OK")) {

                                    Toast.makeText(getApplicationContext(), "Bienvenid@ " + DataTemporal.usuarioPerfil.getNombre(), Toast.LENGTH_LONG).show();

                                    Intent intentActivityMenuPrincipal = new Intent(MainActivity.this, MenuPrincipalActivity.class);

                                    btnIniciarSesion.launch(intentActivityMenuPrincipal);
                                }

                                else {
                                    Toast.makeText(getApplicationContext(), " ===> Los datos para inicio de sesión no son validos", Toast.LENGTH_LONG).show();
                                }


                            }
                            catch (JSONException e) {
                                Toast.makeText(getApplicationContext(), " ===> Error: Algo Paso", Toast.LENGTH_LONG).show();
                                e.printStackTrace();
                            }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Toast.makeText(getApplicationContext(), "=====> Respuesta de Error de URL_VOLLEY_LOGIN via POST - response.toString(): " + error.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
            );

            Singleton.getInstance(getApplicationContext()).addToRequestQueue(solicitudValidarUsuario);

        }
    }

    ActivityResultLauncher<Intent> btnIniciarSesion = registerForActivityResult(

            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult resultado) {

                    if(resultado.getResultCode() == RESULT_OK){
                        Toast.makeText(getApplicationContext(), "Se ha cerrado sesión correctamente ", Toast.LENGTH_LONG).show();
                    }
                    else {
                        Toast.makeText(getApplicationContext(), "===> Error: Algo Paso ", Toast.LENGTH_LONG).show();
                    }
                }
            }
    );
}