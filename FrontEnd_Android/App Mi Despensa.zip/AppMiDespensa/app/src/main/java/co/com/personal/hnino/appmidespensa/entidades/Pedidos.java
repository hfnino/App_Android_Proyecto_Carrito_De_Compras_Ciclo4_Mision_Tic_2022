package co.com.personal.hnino.appmidespensa.entidades;

public class Pedidos {

    private Integer id;
    private Integer id_usuario;
    private Integer id_estado;

    public Pedidos(){

    }

    public Pedidos(Integer id, Integer id_usuario, Integer id_estado) {
        this.id = id;
        this.id_usuario = id_usuario;
        this.id_estado = id_estado;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getId_usuario() {
        return id_usuario;
    }

    public void setId_usuario(Integer id_usuario) {
        this.id_usuario = id_usuario;
    }

    public Integer getId_estado() {
        return id_estado;
    }

    public void setId_estado(Integer id_estado) {
        this.id_estado = id_estado;
    }

    @Override
    public String toString() {
        return "Pedidos{" +
                "id=" + id +
                ", id_usuario=" + id_usuario +
                ", id_estado=" + id_estado +
                '}';
    }
}

